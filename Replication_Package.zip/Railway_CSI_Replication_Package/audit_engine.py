"""Reproducible CSI zero-window audit and fitted-NB2 full-scan checks.

Array order is indicator, country, calendar year.  The primary design uses five
baseline years and five candidate years.  Other durations are exploratory.
"""
from __future__ import annotations

import math
from pathlib import Path
import json
from typing import Any

import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar
from scipy.special import gammaln, xlogy
from scipy.stats import beta

INDICATORS = [f"I0{i}" for i in range(1, 7)]
DEFAULT_EXPOSURE = {code: "R03" if i < 3 else "R01"
                    for i, code in enumerate(INDICATORS)}
ALPHA_LOG_BOUNDS = (-12.0, 5.0)


def load_panel(source, start_year=2010, end_year=2024, exposure_map=None):
    """Read an ERA values dictionary (or its JSON path), preserving missingness.

    source['values'] maps 'country|indicator|year' to numeric values or None.
    Returned counts/exposure have shape (6, n_countries, n_years), with NaN
    for absent values; valid requires a nonnegative count and positive exposure.
    """
    if isinstance(source, (str, Path)):
        with open(source, encoding="utf-8") as handle:
            source = json.load(handle)
    countries = [c for c in source["countries"] if c != "CT"]
    years = np.arange(start_year, end_year + 1, dtype=int)
    exposure_map = dict(DEFAULT_EXPOSURE if exposure_map is None else exposure_map)
    shape = (len(INDICATORS), len(countries), len(years))
    counts = np.full(shape, np.nan)
    exposure = np.full(shape, np.nan)
    values = source["values"]
    for ii, code in enumerate(INDICATORS):
        for cc, country in enumerate(countries):
            for tt, year in enumerate(years):
                for array, value_code in [(counts, code), (exposure, exposure_map[code])]:
                    value = values.get(f"{country}|{value_code}|{year}")
                    if value is not None:
                        array[ii, cc, tt] = float(value)
    valid = np.isfinite(counts) & (counts >= 0) & np.isfinite(exposure) & (exposure > 0)
    if np.any(np.abs(counts[valid] - np.round(counts[valid])) > 1e-8):
        raise ValueError("Observed event counts must be nonnegative integers")
    return dict(countries=countries, indicators=INDICATORS.copy(), years=years,
                counts=counts, exposure=exposure, valid=valid, exposure_map=exposure_map)


def fit_nb2(panel, counts=None):
    """Fit one NB2 alpha per indicator with fixed exposure-weighted country rates.

    Rates use all valid years, including zeros.  All-zero country series have
    fitted mean zero and contribute constant likelihood one; only positive-mean
    rows enter the reported dispersion-estimation n.  Alpha=0 is the Poisson
    boundary.  The bounded log-alpha optimization is compared with that boundary.
    """
    y = panel["counts"] if counts is None else np.asarray(counts)
    valid = panel["valid"]
    yy = np.where(valid, y, 0.0)
    ee = np.where(valid, panel["exposure"], 0.0)
    total_e = ee.sum(axis=-1)
    rates = np.divide(yy.sum(axis=-1), total_e,
                      out=np.zeros(total_e.shape), where=total_e > 0)
    means = rates[..., None] * ee
    alphas, logliks, observations, converged = [], [], [], []
    boundary = []
    for ii in range(len(panel["indicators"])):
        informative = valid[ii] & (means[ii] > 0)
        yi = yy[ii][informative]
        mui = means[ii][informative]
        observations.append(len(yi))
        if not len(yi):
            alphas.append(0.0); logliks.append(0.0)
            converged.append(True); boundary.append(True)
            continue
        logmu = np.log(mui)
        factorial = gammaln(yi + 1.0)
        poisson_ll = float(np.sum(xlogy(yi, mui) - mui - factorial))

        def negative_ll(logalpha):
            alpha = np.exp(logalpha)
            size = 1.0 / alpha
            return -float(np.sum(gammaln(yi + size) - gammaln(size) - factorial
                                 + yi * (logalpha + logmu)
                                 - (yi + size) * np.log1p(alpha * mui)))

        result = minimize_scalar(negative_ll, bounds=ALPHA_LOG_BOUNDS,
                                 method="bounded", options={"xatol": 1e-8})
        at_boundary = result.x <= ALPHA_LOG_BOUNDS[0] + 0.01 or -result.fun <= poisson_ll
        alpha = 0.0 if at_boundary else float(np.exp(result.x))
        ll = poisson_ll if at_boundary else float(-result.fun)
        alphas.append(alpha); logliks.append(ll)
        converged.append(bool(result.success and result.x < ALPHA_LOG_BOUNDS[1] - 0.01))
        boundary.append(at_boundary)
    return dict(rates=rates, means=means, alpha=np.array(alphas),
                loglik=np.array(logliks), nobs=np.array(observations, dtype=int),
                converged=np.array(converged), poisson_boundary=np.array(boundary))


def make_geometry(panel, baseline_years=5, window_years=5):
    """Precompute exposure sums and complete-calendar starts before zero selection."""
    b, w = int(baseline_years), int(window_years)
    if b < 1 or w < 1:
        raise ValueError("Baseline and candidate durations must be positive")
    shape = panel["counts"].shape
    n, t = int(np.prod(shape[:-1])), shape[-1]
    starts = np.arange(b, t - w + 1, dtype=int)
    if not len(starts):
        raise ValueError("Calendar shorter than baseline plus candidate window")
    valid = panel["valid"].reshape(n, t)
    exposure = np.where(valid, panel["exposure"].reshape(n, t), 0.0)
    cv = np.pad(np.cumsum(valid, axis=1), ((0, 0), (1, 0)))
    ce = np.pad(np.cumsum(exposure, axis=1), ((0, 0), (1, 0)))
    eligible = cv[:, starts + w] - cv[:, starts - b] == b + w
    eb = ce[:, starts] - ce[:, starts - b]
    er = ce[:, starts + w] - ce[:, starts]
    logfraction = np.zeros(eb.shape)
    np.log(np.divide(eb, eb + er, out=np.ones(eb.shape), where=eligible),
           out=logfraction)
    return dict(shape=shape, starts=starts, baseline_years=b, window_years=w,
                valid=valid, exposure=exposure, eligible=eligible,
                eligible_starts=eligible.sum(axis=1), baseline_exposure=eb,
                window_exposure=er, logfraction=logfraction)


def scan_arrays(counts, geometry):
    """Compute zero-window minima on a log scale; no qualifying zero gives log(T)=0."""
    n, t = geometry["valid"].shape
    y = np.where(geometry["valid"], np.asarray(counts).reshape(n, t), 0)
    cumulative = np.pad(np.cumsum(y, axis=1), ((0, 0), (1, 0)))
    starts = geometry["starts"]
    b, w = geometry["baseline_years"], geometry["window_years"]
    baseline = cumulative[:, starts] - cumulative[:, starts - b]
    candidate = cumulative[:, starts + w] - cumulative[:, starts]
    zero = geometry["eligible"] & (baseline > 0) & (candidate == 0)
    logs = np.where(zero, baseline * geometry["logfraction"], 0.0)
    selected = np.argmin(logs, axis=1)
    lograw = logs[np.arange(n), selected]
    logbonf = np.minimum(0.0, lograw + np.log(np.maximum(1, geometry["eligible_starts"])))
    logholm = holm_log(logbonf)
    return dict(log_raw_p=lograw, log_bonferroni_p=logbonf,
                log_poisson_holm_p=logholm, selected=selected,
                baseline_counts=baseline, zero_windows=zero.sum(axis=1),
                poisson_flag=logholm <= np.log(0.05))


def holm_log(logp):
    """Holm adjustment of a full family; valid for dependent marginal p-values."""
    logp = np.asarray(logp, dtype=float)
    order = np.argsort(logp, kind="stable")
    adjusted = np.minimum(0.0, np.maximum.accumulate(logp[order] + np.log(np.arange(len(logp), 0, -1))))
    result = np.empty(len(logp))
    result[order] = adjusted
    return result


def probability_text(logp):
    """Preserve very small nonzero probabilities that underflow float64."""
    if logp == 0:
        return "1"
    exponent = int(np.floor(logp / np.log(10.0)))
    mantissa = np.exp(logp - exponent * np.log(10.0))
    return f"{mantissa:.10g}e{exponent:+d}"


def scan_panel(panel, counts=None, baseline_years=5, window_years=5):
    """Return all series, including complete series without a zero and unassessed series."""
    counts = panel["counts"] if counts is None else np.asarray(counts)
    geometry = make_geometry(panel, baseline_years, window_years)
    result = scan_arrays(counts, geometry)
    flat = counts.reshape(geometry["valid"].shape)
    records = []
    nc = len(panel["countries"])
    for j, (ii, cc) in enumerate(np.ndindex(len(panel["indicators"]), nc)):
        has_zero = result["zero_windows"][j] > 0
        k = result["selected"][j]
        start = geometry["starts"][k]
        baseline_count = result["baseline_counts"][j, k] if has_zero else np.nan
        eb = geometry["baseline_exposure"][j, k] if has_zero else np.nan
        er = geometry["window_exposure"][j, k] if has_zero else np.nan
        run = longest = 0
        for iszero in geometry["valid"][j] & (flat[j] == 0):
            run = run + 1 if iszero else 0
            longest = max(longest, run)
        records.append(dict(
            country=panel["countries"][cc], indicator=panel["indicators"][ii],
            eligible_starts=int(geometry["eligible_starts"][j]),
            zero_windows=int(result["zero_windows"][j]),
            baseline_start=int(panel["years"][start - baseline_years]) if has_zero else np.nan,
            baseline_end=int(panel["years"][start - 1]) if has_zero else np.nan,
            window_start=int(panel["years"][start]) if has_zero else np.nan,
            window_end=int(panel["years"][start + window_years - 1]) if has_zero else np.nan,
            baseline_count=baseline_count, baseline_exposure=eb, window_exposure=er,
            expected_window_count=baseline_count * er / eb if has_zero else np.nan,
            log_raw_p=result["log_raw_p"][j],
            raw_p=float(np.exp(result["log_raw_p"][j])),
            raw_p_text=probability_text(result["log_raw_p"][j]),
            bonferroni_p=float(np.exp(result["log_bonferroni_p"][j])),
            poisson_holm_p=float(np.exp(result["log_poisson_holm_p"][j])),
            log_poisson_holm_p=result["log_poisson_holm_p"][j],
            poisson_flag=bool(result["poisson_flag"][j]), longest_zero_run=int(longest)))
    return pd.DataFrame.from_records(records)


def _seed_words(seed):
    return [int(seed)] if np.isscalar(seed) else [int(s) for s in seed]


def mc_scan_probability(mean, alpha, geometry, series_index, observed_log_t,
                        draws=200000, seed=20261009, chunk_size=20000):
    """Exact fixed-number Monte Carlo tail count under a fitted NB2 null.

    Uses the full scan, not just the observed zero window.  Simulations with no
    qualifying zero have T=1 and remain in the denominator.  Alpha=0 generates
    Poisson data.  All randomness is local to the supplied deterministic seed.
    """
    rng = np.random.default_rng(np.random.SeedSequence(_seed_words(seed)))
    mean = np.asarray(mean, dtype=float)
    starts = geometry["starts"]
    b, w = geometry["baseline_years"], geometry["window_years"]
    eligible = geometry["eligible"][series_index]
    logfraction = geometry["logfraction"][series_index]
    exceedances = 0
    for begin in range(0, draws, chunk_size):
        size = (min(chunk_size, draws - begin), len(mean))
        if alpha == 0:
            simulated = rng.poisson(mean, size=size)
        else:
            r = 1.0 / alpha
            simulated = rng.negative_binomial(r, r / (r + mean), size=size)
        cumulative = np.pad(np.cumsum(simulated, axis=1), ((0, 0), (1, 0)))
        baseline = cumulative[:, starts] - cumulative[:, starts - b]
        candidate = cumulative[:, starts + w] - cumulative[:, starts]
        zero = eligible[None, :] & (baseline > 0) & (candidate == 0)
        log_t = np.min(np.where(zero, baseline * logfraction[None, :], 0.0), axis=1)
        exceedances += int(np.count_nonzero(log_t <= observed_log_t))
    return (exceedances + 1) / (draws + 1), exceedances


def run_audit(panel, baseline_years=5, window_years=5, fit=None,
              inner_draws=200000, seed=20261009, chunk_size=20000, counts=None):
    """Apply Poisson prefilter, NB2 full-scan check, Holm168, and intersection.

    Uncomputed NB2 p-values are assigned one, retaining the complete family.
    Consequently the prefilter never reduces the family-size correction.
    """
    y = panel["counts"] if counts is None else np.asarray(counts)
    fit = fit_nb2(panel, y) if fit is None else fit
    frame = scan_panel(panel, y, baseline_years, window_years)
    geometry = make_geometry(panel, baseline_years, window_years)
    n, t = geometry["valid"].shape
    pnb = np.ones(n)
    hits = np.full(n, -1, dtype=int)
    numbers = np.zeros(n, dtype=int)
    means = fit["means"].reshape(n, t)
    nc = len(panel["countries"])
    for j in np.flatnonzero(frame["poisson_flag"].to_numpy()):
        pnb[j], hits[j] = mc_scan_probability(
            means[j], fit["alpha"][j // nc], geometry, j,
            frame.loc[j, "log_raw_p"], draws=inner_draws,
            seed=_seed_words(seed) + [baseline_years, window_years, int(j)],
            chunk_size=chunk_size)
        numbers[j] = inner_draws
    frame["nb_mc_exceedances"] = hits
    frame["nb_mc_draws"] = numbers
    frame["nb_raw_p"] = pnb
    frame["nb_holm_p"] = np.exp(holm_log(np.log(pnb)))
    frame["final_flag"] = frame["poisson_flag"] & (frame["nb_holm_p"] <= 0.05)
    return frame, fit


def binomial_interval(successes, trials, confidence=0.95):
    """Two-sided Clopper-Pearson interval, including zero/all-success endpoints."""
    tail = (1.0 - confidence) / 2
    low = 0.0 if successes == 0 else float(beta.ppf(tail, successes, trials - successes + 1))
    high = 1.0 if successes == trials else float(beta.ppf(1 - tail, successes + 1, trials - successes))
    return low, high


def fit_table(panel, fit):
    """Human-readable indicator-level dispersion fit results."""
    return pd.DataFrame(dict(indicator=panel["indicators"], alpha=fit["alpha"],
                             observations=fit["nobs"], log_likelihood=fit["loglik"],
                             converged=fit["converged"], poisson_boundary=fit["poisson_boundary"]))
