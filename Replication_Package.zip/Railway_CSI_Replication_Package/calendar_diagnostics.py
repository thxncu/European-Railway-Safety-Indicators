"""Calendar-preserving pandemic sensitivity and simple-rule comparisons."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from audit_engine import load_panel, run_audit
from report_outputs import INDICATORS, comparison_windows, read_source, source_value


def run(data, observed, output, inner_draws=200000, seed=20271019):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    source = read_source(data)
    panel = load_panel(source)
    scans = pd.read_csv(observed, float_precision="round_trip")
    rule_rows, window_rows, timing_rows = [], [], []
    for duration, floor in [(3, 22), (4, 18), (5, 15), (6, 13), (7, 11)]:
        scan = scans[scans.window_years == duration]
        for i, indicator in enumerate(INDICATORS):
            for j, country in enumerate(panel["countries"]):
                windows = comparison_windows(panel, i, j, duration=duration)
                zero_windows = [w for w in windows if w["zero_window"]]
                simple = any(w["baseline_count"] >= floor for w in zero_windows)
                selected = scan[(scan.country == country) & (scan.indicator == indicator)].iloc[0]
                rule_rows.append(dict(window_years=duration, country=country, indicator=indicator,
                                      baseline_count_floor=floor, complete_zero_windows=len(zero_windows),
                                      simple_rule_flag=bool(simple), final_flag=bool(selected.final_flag)))
                for w in zero_windows:
                    window_rows.append(dict(window_years=duration, country=country, indicator=indicator,
                                            preceding_year_positive=bool(panel["counts"][i,j,w["start_index"]-1] > 0), **w))
        group = [r for r in window_rows if r["window_years"] == duration]
        timing_rows.append(dict(window_years=duration, complete_zero_windows=len(group),
                                zero_windows_starting_2020=sum(r["window_start"] == 2020 for r in group),
                                zero_runs_starting_2020_after_positive_2019=sum(r["window_start"] == 2020 and r["preceding_year_positive"] for r in group),
                                zero_window_series=int((scan.zero_windows > 0).sum()),
                                selected_windows_starting_2020=int((scan.window_start == 2020).sum())))
    rule_frame = pd.DataFrame(rule_rows)
    rule_frame.to_csv(output/"simple_rule_comparison.csv", index=False)
    pd.DataFrame(window_rows).to_csv(output/"complete_zero_windows.csv", index=False)
    pd.DataFrame(timing_rows).to_csv(output/"zero_window_timing.csv", index=False)
    summaries = []
    for duration, group in rule_frame.groupby("window_years"):
        summaries.append(dict(window_years=duration, baseline_count_floor=int(group.baseline_count_floor.iloc[0]),
                              simple_rule_series="; ".join(group.loc[group.simple_rule_flag,"country"]+"-"+group.loc[group.simple_rule_flag,"indicator"]),
                              final_flag_series="; ".join(group.loc[group.final_flag,"country"]+"-"+group.loc[group.final_flag,"indicator"]),
                              decisions_differ=int((group.simple_rule_flag != group.final_flag).sum())))
    pd.DataFrame(summaries).to_csv(output/"simple_rule_summary.csv", index=False)

    excluded = {2020, 2021}
    modified = {k:(v.copy() if isinstance(v, np.ndarray) else v) for k,v in panel.items()}
    excluded_mask = np.isin(panel["years"], sorted(excluded))
    modified["counts"][:,:,excluded_mask] = np.nan
    modified["valid"][:,:,excluded_mask] = False
    pandemic_scans, _ = run_audit(modified, inner_draws=inner_draws, seed=seed)
    pandemic_scans.to_csv(output/"pandemic_exclusion_scan.csv", index=False)
    pd.DataFrame([dict(excluded_years="2020; 2021", calendar_retained=True,
                       complete_series=int((pandemic_scans.eligible_starts > 0).sum()),
                       zero_window_series=int((pandemic_scans.zero_windows > 0).sum()),
                       poisson_flags=int(pandemic_scans.poisson_flag.sum()),
                       final_flags=int(pandemic_scans.final_flag.sum()),
                       flagged_series="; ".join(pandemic_scans.loc[pandemic_scans.final_flag,"country"]+"-"+pandemic_scans.loc[pandemic_scans.final_flag,"indicator"]))
                 ]).to_csv(output/"pandemic_exclusion_summary.csv", index=False)

    annual = []
    for year in range(2015,2025):
        annual.append(dict(country="RO",year=year,spad_count=source_value(source,"RO","I04",year),
                           subtype_danger_point_passed=source_value(source,"RO","I041",year),
                           subtype_danger_point_not_passed=source_value(source,"RO","I042",year),
                           exposure_million_train_km=source_value(source,"RO","R01",year)))
    annual = pd.DataFrame(annual)
    annual.to_csv(output/"romania_annual_context.csv", index=False)
    periods = []
    for start,end,label in [(2015,2019,"Baseline"),(2020,2021,"Pandemic years"),(2022,2023,"Later zero years"),(2024,2024,"Subsequent year")]:
        group = annual[annual.year.between(start,end)]
        periods.append(dict(period=label,start_year=start,end_year=end,
                            spad_count=int(group.spad_count.sum()),
                            exposure_million_train_km=group.exposure_million_train_km.sum(),
                            annual_mean_exposure=group.exposure_million_train_km.mean()))
    pd.DataFrame(periods).to_csv(output/"romania_period_context.csv", index=False)
    return {"simple_rule":summaries,"zero_window_timing":timing_rows,
            "pandemic_flags":pandemic_scans.loc[pandemic_scans.final_flag,["country","indicator","nb_holm_p"]].to_dict("records"),
            "romania_periods":periods}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data",type=Path,default=Path("data"))
    parser.add_argument("--observed",type=Path,default=Path("results/audit_results.csv"))
    parser.add_argument("--output",type=Path,default=Path("results"))
    parser.add_argument("--inner-draws",type=int,default=200000)
    parser.add_argument("--seed",type=int,default=20271019)
    args=parser.parse_args()
    print(json.dumps(run(args.data,args.observed,args.output,args.inner_draws,args.seed),indent=2))
