"""Source extraction, descriptive results, and figures for the CSI audit."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from openpyxl import load_workbook
from scipy.stats import beta

INDICATORS = [f"I{i:02d}" for i in range(1, 7)]
INDICATOR_NAMES = {
    "I01": "Broken rail", "I02": "Track buckle", "I03": "Wrong-side signalling failure",
    "I04": "Signals passed at danger", "I05": "Broken wheel", "I06": "Broken axle",
}
COUNTRY_NAMES = dict(zip(
    "AT BE BG CH CZ DE DK EE EL ES FI FR HR HU IE IT LT LU LV NL NO PL PT RO SE SI SK UK".split(),
    ["Austria", "Belgium", "Bulgaria", "Switzerland", "Czechia", "Germany", "Denmark",
     "Estonia", "Greece", "Spain", "Finland", "France", "Croatia", "Hungary", "Ireland",
     "Italy", "Lithuania", "Luxembourg", "Latvia", "Netherlands", "Norway", "Poland",
     "Portugal", "Romania", "Sweden", "Slovenia", "Slovakia", "United Kingdom"]))


def read_source(workbook_path):
    """Read published values; blank and nonnumeric entries remain missing."""
    workbook_path = Path(workbook_path)
    if workbook_path.is_dir():
        values, labels, countries = {}, {}, []
        for filename in ("Table0.csv", "Table3.csv", "Table6.csv"):
            frame = pd.read_csv(workbook_path/filename, encoding="utf-8-sig", float_precision="round_trip")
            frame["Code"] = frame["Code"].ffill()
            frame["CSI"] = frame["CSI"].ffill()
            cols = [c for c in frame if len(c)==2 and c.isupper() and c!="CT"]
            if not countries:
                countries = cols
            elif countries != cols:
                raise ValueError("Country columns differ between source tables")
            for _, row in frame.iterrows():
                year = pd.to_numeric(row["Year"], errors="coerce")
                if not np.isfinite(year) or not 2006<=year<=2024:
                    continue
                code = str(row["Code"]).strip()
                labels[code] = str(row["CSI"]).strip()
                for country in countries:
                    try:
                        v = float(row[country])
                    except (TypeError,ValueError):
                        v = np.nan
                    values[f"{country}|{code}|{int(year)}"] = float(v) if np.isfinite(v) else None
        return {"countries":countries,"labels":labels,"values":values}
    wb = load_workbook(workbook_path, read_only=True, data_only=True)
    values, labels, countries = {}, {}, []
    for sheet in ("Table 0", "Table 3", "Table 6"):
        rows = wb[sheet].iter_rows(values_only=True)
        next(rows)
        header = next(rows)
        columns = [(j, str(v)) for j, v in enumerate(header)
                   if isinstance(v, str) and len(v) == 2 and v.isupper() and v != "CT"]
        if not countries:
            countries = [c for _, c in columns]
        elif countries != [c for _, c in columns]:
            raise ValueError("Country columns differ between source tables")
        code = None
        for row in rows:
            if row[1] is not None:
                code = str(row[1]).strip()
            if row[2] is not None and code:
                labels[code] = str(row[2]).strip()
            year = row[3]
            if not code or not isinstance(year, (int, float)) or not 2006 <= year <= 2024:
                continue
            for j, country in columns:
                v = row[j] if j < len(row) else None
                values[f"{country}|{code}|{int(year)}"] = (
                    v if isinstance(v, (int, float)) and math.isfinite(v) else None)
    wb.close()
    return {"countries": countries, "labels": labels, "values": values}


def source_value(source, country, code, year):
    value = source["values"].get(f"{country}|{code}|{int(year)}")
    return np.nan if value is None else float(value)


def source_series(source, country, code, years):
    return np.array([source_value(source, country, code, year) for year in years], dtype=float)


def write_data_dictionary(source, path):
    codes = ["I00", *INDICATORS, "I041", "I042", "N00", "N01", "N011", "N012",
             "N02", "N03", "N04", "N05", "N06", "R01", "R03", "R08"]
    rows = []
    for code in codes:
        rows.append({"code": code, "source_sheet": "Table 3" if code[0] == "I" else
                     "Table 0" if code[0] == "N" else "Table 6",
                     "definition": source["labels"][code],
                     "unit": "million train-kilometres" if code == "R01" else
                     "kilometres" if code in ("R03", "R08") else "events",
                     "missing_values": "Blank or nonnumeric source entries remain missing",
                     "zero_values": "Numeric zero is a reported count" if code[0] != "R" else
                     "Exposure must be positive for an audit comparison"})
    pd.DataFrame(rows).to_csv(path, index=False)


def comparison_windows(panel, indicator_index, country_index, baseline=5, duration=5):
    y = panel["counts"][indicator_index, country_index]
    e = panel["exposure"][indicator_index, country_index]
    valid = panel["valid"][indicator_index, country_index]
    years = panel["years"]
    comparisons = []
    for start in range(baseline, len(years) - duration + 1):
        slb, slr = slice(start-baseline, start), slice(start, start+duration)
        if not valid[start-baseline:start+duration].all():
            continue
        yb, eb, er = y[slb].sum(), e[slb].sum(), e[slr].sum()
        logp = yb * np.log(eb / (eb + er))
        comparisons.append({"start_index": start, "baseline_start": int(years[start-baseline]),
                            "baseline_end": int(years[start-1]), "window_start": int(years[start]),
                            "window_end": int(years[start+duration-1]), "baseline_count": yb,
                            "baseline_exposure": eb, "window_exposure": er,
                            "hypothetical_log_p": logp,
                            "zero_window": bool(y[slr].sum() == 0 and yb > 0)})
    return comparisons


def composition(panel, scans):
    rows, screen_rows, profile_rows = [], [], []
    for duration, scan in sorted(scans.items()):
        screen_total = 0
        for i, indicator in enumerate(INDICATORS):
            eligible, screen = 0, 0
            for c, country in enumerate(panel["countries"]):
                windows = comparison_windows(panel, i, c, duration=duration)
                eligible += bool(windows)
                minimum = min((r["hypothetical_log_p"] for r in windows), default=0.0)
                log_adjusted = min(0., minimum + math.log(max(1, len(windows))))
                meets = bool(windows and log_adjusted <= math.log(.05 / 168))
                screen += meets
                screen_rows.append({"window_years": duration, "country": country,
                                    "indicator": indicator, "eligible_starts": len(windows),
                                    "screen_log_probability": log_adjusted,
                                    "meets_conservative_screen": meets})
            screen_total += screen
            if duration == 5:
                y = panel["counts"][i]
                ei = panel["exposure"][i]
                si = scan[scan.indicator == indicator]
                rows.append({"indicator": indicator, "indicator_name": INDICATOR_NAMES[indicator],
                             "positive_count_cells": int(np.sum(y > 0)),
                             "zero_count_cells": int(np.sum(y == 0)),
                             "missing_count_cells": int(np.sum(~np.isfinite(y))),
                             "missing_exposure_cells": int(np.sum(~np.isfinite(ei))),
                             "nonpositive_exposure_cells": int(np.sum(ei <= 0)),
                             "zero_share_percent": 100*np.sum(y == 0)/np.sum(np.isfinite(y)),
                             "eligible_series": eligible,
                             "zero_window_series": int(np.sum(si.zero_windows > 0)),
                             "screen_series": screen,
                             "poisson_flags": int(si.poisson_flag.sum()),
                             "final_flags": int(si.final_flag.sum())})
        starts = len(panel["years"]) - 5 - duration + 1
        floor = math.ceil(math.log(.05 / (168 * starts)) / math.log(5/(5+duration)))
        flags = scan[scan.final_flag]
        profile_rows.append({"window_years": duration, "baseline_years": 5,
                             "analysis_role": "Primary" if duration == 5 else "Exploratory",
                             "series_tested": int((scan.zero_windows > 0).sum()),
                             "screen_series": screen_total, "equal_exposure_detection_floor": floor,
                             "poisson_flags": int(scan.poisson_flag.sum()),
                             "final_flags": len(flags),
                             "flagged_series": "; ".join(flags.country + "-" + flags.indicator)})
    return pd.DataFrame(rows), pd.DataFrame(profile_rows), pd.DataFrame(screen_rows)


def deletion_diagnostics(panel, scans):
    rows = []
    for duration, scan in sorted(scans.items()):
        for _, case in scan[scan.final_flag].iterrows():
            i = INDICATORS.index(case.indicator)
            c = panel["countries"].index(case.country)
            years = panel["years"]
            b = (years >= case.baseline_start) & (years <= case.baseline_end)
            r = (years >= case.window_start) & (years <= case.window_end)
            y, e = panel["counts"][i,c], panel["exposure"][i,c]
            yb, eb, er = y[b].sum(), e[b].sum(), e[r].sum()
            delete_logp = (yb-y[b]) * np.log((eb-e[b])/(eb-e[b]+er))
            ws = np.flatnonzero(r)[0]
            br = e[ws] / e[ws-1] - 1
            biggest_index = int(np.argmax(y[b]))
            first = np.flatnonzero(b)[0]
            differences = e[first+1:ws+1]/e[first:ws]-1
            change_index = first+1+int(np.argmax(np.abs(differences)))
            change_year = int(years[change_index])
            post_logp = np.nan
            if change_index<ws:
                after = slice(change_index,ws)
                post_e,post_y = e[after].sum(),y[after].sum()
                post_logp = post_y*np.log(post_e/(post_e+er))
            rows.append({"country": case.country, "indicator": case.indicator,
                         "window_years": duration, "baseline_start": int(case.baseline_start),
                         "baseline_end": int(case.baseline_end), "window_start": int(case.window_start),
                         "window_end": int(case.window_end), "baseline_count": yb,
                         "largest_baseline_year": int(years[b][biggest_index]),
                         "largest_baseline_share_percent": 100*np.max(y[b])/yb,
                         "smallest_deletion_log_p": float(delete_logp.min()),
                         "smallest_deletion_raw_p": float(np.exp(delete_logp.min())),
                         "worst_deletion_log_p": float(delete_logp.max()),
                         "worst_deletion_raw_p": float(np.exp(delete_logp.max())),
                         "worst_deleted_year": int(years[b][np.argmax(delete_logp)]),
                         "boundary_exposure_change_percent": 100*br,
                         "largest_exposure_change_year": change_year,
                         "largest_exposure_change_percent": 100*float(differences[change_index-first-1]),
                         "post_change_baseline_log_p": post_logp,
                         "post_change_baseline_raw_p": np.exp(post_logp),
                         "longest_zero_run": int(case.longest_zero_run)})
    return pd.DataFrame(rows)


def accident_comparison(source, country, indicator, baseline_start, baseline_end,
                        window_start, window_end, lag=0):
    by = np.arange(int(baseline_start)+lag, int(baseline_end)+lag+1)
    wy = np.arange(int(window_start)+lag, int(window_end)+lag+1)
    codes = ["N01", "N02"] if indicator in ("I03", "I04") else ["N02"]
    bc = np.array([source_series(source,country,k,by) for k in codes])
    wc = np.array([source_series(source,country,k,wy) for k in codes])
    be = source_series(source,country,"R01",by)
    we = source_series(source,country,"R01",wy)
    if not all(np.isfinite(v).all() for v in (bc,wc,be,we)) or np.any(be<=0) or np.any(we<=0):
        raise ValueError(f"Incomplete accident comparison: {country} {indicator} lag {lag}")
    nb,nw,eb,ew = bc.sum(),wc.sum(),be.sum(),we.sum()
    rr = (nw/ew)/(nb/eb) if nb else np.inf
    lo = beta.ppf(.025,nw,nb+1) if nw else 0.
    hi = beta.ppf(.975,nw+1,nb) if nb else 1.
    low = lo/(1-lo)*eb/ew
    high = hi/(1-hi)*eb/ew if hi<1 else np.inf
    return {"country":country,"indicator":indicator,"lag":lag,"baseline_start":int(by[0]),
            "baseline_end":int(by[-1]),"window_start":int(wy[0]),"window_end":int(wy[-1]),
            "accident_codes":" + ".join(codes),"baseline_events":int(nb),"window_events":int(nw),
            "baseline_train_km_million":eb,"window_train_km_million":ew,
            "rate_ratio":rr,"ci_lower":low,"ci_upper":high}


def arithmetic_identities(source):
    definitions = {
        "Precursor total": ("I00", INDICATORS),
        "SPAD total": ("I04", ["I041", "I042"]),
        "Significant-accident total": ("N00", [f"N{i:02d}" for i in range(1,7)]),
        "Collision total": ("N01", ["N011", "N012"]),
    }
    rows, summary = [], []
    for label, (total, components) in definitions.items():
        tested, failed = 0, 0
        for country in source["countries"]:
            for year in range(2010,2025):
                vals = [source_value(source,country,k,year) for k in [total,*components]]
                if not np.isfinite(vals).all():
                    continue
                tested += 1
                difference = vals[0]-sum(vals[1:])
                if abs(difference)>1e-9:
                    failed += 1
                    rows.append({"identity":label,"country":country,"country_name":COUNTRY_NAMES[country],
                                 "year":year,"reported_total":vals[0],"component_sum":sum(vals[1:]),
                                 "difference":difference})
        summary.append({"identity":label,"complete_comparisons":tested,"discrepancies":failed,
                        "discrepancy_percent":100*failed/tested})
    return pd.DataFrame(summary), pd.DataFrame(rows)


def calendar_adjusted_scan(source,panel,duration=5):
    from audit_engine import scan_panel
    modified = dict(panel)
    weighted = np.full_like(panel["exposure"],np.nan)
    for i in range(6):
        valid = panel["valid"][i]
        count = np.where(valid,panel["counts"][i],0.)
        expo = np.where(valid,panel["exposure"][i],0.)
        for c in range(len(panel["countries"])):
            total_count = count.sum(axis=0)-count[c]
            total_expo = expo.sum(axis=0)-expo[c]
            rate = np.divide(total_count,total_expo,out=np.full_like(total_count,np.nan),where=total_expo>0)
            weighted[i,c] = panel["exposure"][i,c]*rate
    modified["exposure"] = weighted
    modified["valid"] = np.isfinite(panel["counts"]) & np.isfinite(weighted) & (weighted>0)
    result = scan_panel(modified,baseline_years=5,window_years=duration)
    result.insert(0,"window_years",duration)
    return result


def additional_sensitivities(source, scans, output, draws=200000, seed=20261109):
    from audit_engine import load_panel, run_audit
    summaries, frames = [], []

    def add(label, group, frame, first_year=2010, baseline=5, duration=5):
        copy = frame.copy()
        copy.insert(0,"specification",label)
        copy["analysis_start"] = first_year
        copy["baseline_years"] = baseline
        copy["window_years"] = duration
        copy["analysis_role"] = "Exploratory"
        frames.append(copy)
        flagged = frame[frame.final_flag]
        summaries.append({"specification":label,"group":group,"analysis_start":first_year,
                          "baseline_years":baseline,"window_years":duration,
                          "poisson_flags":int(frame.poisson_flag.sum()),
                          "nb_flags":int((frame.nb_holm_p<=.05).sum()),
                          "final_flags":len(flagged),
                          "flagged_series":"; ".join(flagged.country+"-"+flagged.indicator)})

    add("Indicator-specific exposure","Exposure",scans[5])
    for j,(code,label) in enumerate([("R01","Train-kilometres"),("R03","Track-kilometres"),("R08","Line-kilometres")],1):
        panel=load_panel(source,exposure_map={k:code for k in INDICATORS})
        frame,_=run_audit(panel,inner_draws=draws,seed=seed+j)
        add(label+" for all indicators","Exposure",frame)
    for baseline in [4,5,6,8]:
        if baseline==5:
            frame=scans[5]
        else:
            frame,_=run_audit(load_panel(source),baseline_years=baseline,inner_draws=draws,seed=seed+100+baseline)
        add(f"Baseline {baseline} years; zero window 5 years","Window",frame,baseline=baseline)
    for duration in [4,6]:
        add(f"Baseline 5 years; zero window {duration} years","Window",scans[duration],duration=duration)
    frame,_=run_audit(load_panel(source,start_year=2006),inner_draws=draws,seed=seed+200)
    add("Extended 2006-2024; baseline 5; zero window 5","Window",frame,first_year=2006)
    output=Path(output)
    summary=pd.DataFrame(summaries)
    all_scans=pd.concat(frames,ignore_index=True)
    summary.to_csv(output/"sensitivity_summary.csv",index=False)
    all_scans.to_csv(output/"sensitivity_scans.csv",index=False)
    return summary,all_scans


def supplemental_metrics(panel, scans, screens, output):
    from audit_engine import holm_log
    output=Path(output)
    rows=[]
    for family,keep in [("All series",np.ones(168,dtype=bool)),
                        ("Conservative-screen series",screens[screens.window_years==5].meets_conservative_screen.to_numpy()),
                        ("Tested zero-window series",scans[5].zero_windows.to_numpy()>0)]:
        selected=scans[5].loc[keep].copy()
        logbonf=np.minimum(0,selected.log_raw_p+np.log(np.maximum(1,selected.eligible_starts)))
        flags=holm_log(logbonf)<=np.log(.05)
        final=flags & (np.exp(holm_log(np.log(selected.nb_raw_p)))<=.05)
        rows.append({"family":family,"series":int(keep.sum()),"poisson_flags":int(flags.sum()),
                     "final_flags":int(final.sum()),
                     "flagged_series":"; ".join((selected.country+"-"+selected.indicator)[final])})
    pd.DataFrame(rows).to_csv(output/"correction_family_sensitivity.csv",index=False)
    i=INDICATORS.index("I04")
    country_keep=np.array(panel["countries"])!="RO"
    y,e=panel["counts"][i,country_keep],panel["exposure"][i,country_keep]
    valid=panel["valid"][i,country_keep]
    yearly=pd.DataFrame({"year":panel["years"],"reporting_countries":valid.sum(axis=0),
                         "events":np.where(valid,y,0).sum(axis=0),
                         "train_km_million":np.where(valid,e,0).sum(axis=0)})
    yearly["events_per_billion_train_km"]=1000*yearly.events/yearly.train_km_million
    yearly.to_csv(output/"spad_european_context.csv",index=False)
    periods=[]
    for a,b in [(2015,2019),(2020,2023)]:
        values=yearly[yearly.year.between(a,b)]
        periods.append({"start_year":a,"end_year":b,"events":values.events.sum(),
                        "train_km_million":values.train_km_million.sum(),
                        "events_per_billion_train_km":1000*values.events.sum()/values.train_km_million.sum()})
    pd.DataFrame(periods).to_csv(output/"spad_european_periods.csv",index=False)
    concentration=[]
    for i,k in enumerate(INDICATORS):
        for c,country in enumerate(panel["countries"]):
            good=np.isfinite(panel["counts"][i,c])
            values=panel["counts"][i,c,good]
            if not len(values) or values.sum()<=0:continue
            arg=int(np.argmax(values))
            concentration.append({"country":country,"indicator":k,"total_events":values.sum(),
                                  "largest_year":int(panel["years"][good][arg]),
                                  "largest_year_count":values[arg],"largest_year_share":values[arg]/values.sum()})
    pd.DataFrame(concentration).to_csv(output/"annual_count_concentration.csv",index=False)


def descriptive_outputs(source,panel,scans,output):
    output = Path(output); output.mkdir(parents=True,exist_ok=True)
    comp,profile,screen = composition(panel,scans)
    diagnostics = deletion_diagnostics(panel,scans)
    accidents,lagged = [],[]
    primary_cases = scans[5].loc[scans[5].final_flag,["country","indicator"]]
    primary_keys = set(zip(primary_cases.country,primary_cases.indicator))
    primary_diagnostics = diagnostics[(diagnostics.window_years==5)]
    exploratory_diagnostics = diagnostics[
        [tuple(x) not in primary_keys for x in diagnostics[["country","indicator"]].to_numpy()]]
    selected = pd.concat([primary_diagnostics,
                          exploratory_diagnostics.sort_values("window_years").drop_duplicates(["country","indicator"])])
    for _,row in selected.iterrows():
        result = accident_comparison(source,row.country,row.indicator,row.baseline_start,
                                     row.baseline_end,row.window_start,row.window_end)
        result["analysis_role"] = "Primary" if (row.country,row.indicator) in primary_keys else "Exploratory"
        accidents.append(result)
    for _,row in scans[5][scans[5].final_flag].iterrows():
        for lag in range(3):
            lagged.append(accident_comparison(source,row.country,row.indicator,row.baseline_start,
                                               row.baseline_end,row.window_start,row.window_end,lag))
    identities,discrepancies = arithmetic_identities(source)
    calendar = pd.concat([calendar_adjusted_scan(source,panel,d) for d in sorted(scans)],ignore_index=True)
    outputs = {"table_1_composition":comp,"table_2_persistence":profile,
               "conservative_screen":screen,"case_diagnostics":diagnostics,
               "matched_accident_rates":pd.DataFrame(accidents),
               "table_S7_accident_lags":pd.DataFrame(lagged),"table_S8_arithmetic":identities,
               "table_S9_discrepancies":discrepancies,"calendar_sensitivity":calendar}
    for name,frame in outputs.items():frame.to_csv(output/f"{name}.csv",index=False)
    series = []
    for country,indicator in [("BG","I02"),("PL","I03"),("RO","I04"),("BG","I06"),("EL","I04"),("HU","I03")]:
        for year in panel["years"]:
            series.append({"country":country,"indicator":indicator,"year":int(year),
                           "count":source_value(source,country,indicator,year)})
    outputs["figure_3_data"] = pd.DataFrame(series)
    outputs["figure_3_data"].to_csv(output/"figure_3_data.csv",index=False)
    return outputs


def make_figures(outputs, scans, output):
    """Draw monochrome figures at a 6.5-inch manuscript width."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch
    from matplotlib.ticker import ScalarFormatter, MaxNLocator
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "Nimbus Sans"],
        "font.size": 10,
        "axes.titlesize": 10,
        "axes.labelsize": 10,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
        "text.color": "black",
        "axes.labelcolor": "black",
        "axes.edgecolor": "black",
        "xtick.color": "black",
        "ytick.color": "black",
        "axes.linewidth": 0.8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.facecolor": "white",
        "figure.facecolor": "white",
        "savefig.facecolor": "white",
        "pdf.use14corefonts": True,
        "mathtext.fontset": "stix",
    })

    def save_figure(figure, number):
        from io import BytesIO
        for extension, metadata in [
            ("png", {"Software": None}),
            ("pdf", {"Creator": None, "Producer": None,
                     "CreationDate": None, "ModDate": None})]:
            buffer = BytesIO()
            figure.savefig(buffer, format=extension, dpi=600, metadata=metadata)
            destination = output / f"figure_{number}.{extension}"
            temporary = output / f"figure_{number}.{extension}.tmp"
            temporary.write_bytes(buffer.getvalue())
            temporary.replace(destination)
        plt.close(figure)

    comp, profile = outputs["table_1_composition"], outputs["table_2_persistence"]
    profile = profile.sort_values("window_years")
    fig, (ax, bx) = plt.subplots(
        1, 2, figsize=(6.5, 5.3), gridspec_kw={"width_ratios": [1.05, 1]})
    ordered = comp.sort_values("zero_share_percent")
    labels = [{"I03": "Signalling\nfailure", "I04": "SPADs"}.get(
        code, INDICATOR_NAMES[code]) for code in ordered.indicator]
    positions = np.arange(6)
    zeros = ordered.zero_share_percent.to_numpy()
    screen = 100 * ordered.screen_series.to_numpy() / 28
    ax.barh(positions + .17, zeros, height=.29, facecolor="black",
            edgecolor="black", lw=.8)
    ax.barh(positions - .17, screen, height=.29, facecolor="white",
            edgecolor="black", lw=.8)
    for j, (_, row) in enumerate(ordered.iterrows()):
        observed = int(row.positive_count_cells + row.zero_count_cells)
        ax.text(zeros[j] + 2.5, j + .17,
                f"{int(row.zero_count_cells)}/{observed}", va="center", fontsize=10)
        ax.text(screen[j] + 2.5, j - .17,
                f"{int(row.screen_series)}/28", va="center", fontsize=10)
    ax.set_yticks(positions, labels)
    ax.set_xlim(0, 139)
    ax.set_xticks([0, 25, 50, 75, 100])
    ax.set_xlabel("Percentage (%)")
    ax.set_ylim(-.65, 5.65)
    ax.set_title("(A) Frequency and coverage", loc="left", pad=12)
    ax.legend(handles=[
        Patch(facecolor="black", edgecolor="black",
              label="Zeros / observed count cells"),
        Patch(facecolor="white", edgecolor="black",
              label="Screen / 28 national series")],
        loc="upper left", bbox_to_anchor=(-.03, -.16), frameon=False,
        fontsize=9.5, handlelength=1.3, labelspacing=.7)

    primary = scans[5]
    tested = primary[primary.zero_windows > 0]
    for _, row in tested.iterrows():
        symbol = "o" if row.indicator in ("I05", "I06") else "^"
        bx.scatter(row.baseline_count, row.bonferroni_p, marker=symbol, s=35,
                   facecolor="black" if row.final_flag else "white",
                   edgecolor="black", linewidths=.8, zorder=3)
    for threshold in (12, 15):
        bx.axvline(threshold, color="black", linestyle=":", linewidth=.8, zorder=1)
    bx.text(12, .90, "12", fontsize=9, ha="right", va="bottom")
    bx.text(15, .14, "15", fontsize=9, ha="left", va="bottom")
    bx.axhline(.05 / 168, color="black", linestyle="--", linewidth=.8)
    bx.text(1.05, .05 / 168 * 2.5, "Strictest Holm\ncutoff", fontsize=9)
    for _, row in tested[tested.final_flag].iterrows():
        label = ("Bulgaria\ntrack buckle" if row.indicator == "I02"
                 else "Poland\nsignalling failure")
        position = (2.1, 2e-7) if row.indicator == "I02" else (8, 1e-10)
        bx.annotate(label, xy=(row.baseline_count, row.bonferroni_p),
                    xytext=position, fontsize=9.5,
                    bbox={"facecolor": "white", "edgecolor": "none", "pad": 1},
                    arrowprops={"arrowstyle": "-", "color": "black", "lw": .8})
    bx.set_xscale("log")
    bx.set_yscale("log")
    bx.set_xlim(.85, 65)
    bx.set_ylim(1e-14, 2)
    bx.set_xticks([1, 2, 5, 10, 20, 50])
    bx.xaxis.set_major_formatter(ScalarFormatter())
    bx.set_xlabel("Baseline events\n(preceding five years)")
    bx.set_ylabel("Within-series Bonferroni probability")
    bx.set_title("(B) Five-year scan", loc="left", pad=12)
    handles = [
        Line2D([], [], marker="o", ls="", mfc="white", mec="black",
               label="Wheel or axle"),
        Line2D([], [], marker="^", ls="", mfc="white", mec="black",
               label="Track or signalling"),
        Line2D([], [], marker="^", ls="", color="black", label="Primary flag")]
    bx.legend(handles=handles, loc="lower left", fontsize=9.5, frameon=True,
              facecolor="white", edgecolor="white", framealpha=1,
              handletextpad=.4, borderaxespad=.1)
    fig.subplots_adjust(left=.17, right=.985, bottom=.23, top=.90, wspace=.68)
    save_figure(fig, 1)

    fig = plt.figure(figsize=(6.5, 5.6))
    grid = fig.add_gridspec(2, 2, height_ratios=[1, 1.1], hspace=.80, wspace=.44)
    ax = fig.add_subplot(grid[0, 0])
    bx = fig.add_subplot(grid[0, 1])
    cx = fig.add_subplot(grid[1, :])
    for axis, values, ylabel, title in [
        (ax, profile.series_tested, "Tested series", "(A) Series with a zero window"),
        (bx, profile.equal_exposure_detection_floor, "Baseline events",
         "(B) Equal-exposure screen floor")]:
        axis.plot(profile.window_years, values, "o-", color="black",
                  ms=4, lw=1)
        for x, y in zip(profile.window_years, values):
            axis.annotate(str(int(y)), (x, y), xytext=(0, 7),
                          textcoords="offset points", ha="center", fontsize=10)
        axis.set_xticks(range(3, 8), ["3", "4", "5*", "6", "7"])
        axis.set_xlim(2.7, 7.3)
        axis.set_ylim(0, max(values) * 1.27)
        axis.yaxis.set_major_locator(MaxNLocator(nbins=4, integer=True))
        axis.set_xlabel("Zero-window duration (years)")
        axis.set_ylabel(ylabel)
        axis.set_title(title, loc="left", pad=12)
    cases = [("BG", "I02"), ("PL", "I03"), ("RO", "I04"), ("BG", "I06")]
    case_labels = ["Bulgaria: track buckle", "Poland: signalling failure",
                   "Romania: SPADs", "Bulgaria: broken axle"]
    for y, ((country, indicator), label) in enumerate(zip(cases, case_labels)):
        cx.text(.05, y, label, ha="left", va="center", fontsize=10)
        for duration in range(3, 8):
            row = scans[duration].query(
                "country==@country and indicator==@indicator").iloc[0]
            if row.final_flag:
                cx.scatter(duration, y, s=75, marker="s", facecolor="black",
                           edgecolor="black", zorder=3)
            elif row.zero_windows > 0:
                cx.scatter(duration, y, s=75, marker="s", facecolor="white",
                           edgecolor="black", linewidths=.8, zorder=3)
            else:
                cx.plot(duration, y, marker="x", ms=6, color="black", mew=1)
    cx.set_xticks(range(3, 8), ["3", "4", "5*", "6", "7"])
    cx.set_yticks([])
    cx.set_xlim(0, 7.5)
    cx.set_ylim(3.55, -.55)
    cx.set_xlabel("Zero-window duration (years); * primary specification")
    cx.set_title("(C) Primary and exploratory flags", loc="left", pad=12)
    for spine in cx.spines.values():
        spine.set_visible(False)
    cx.tick_params(axis="both", length=0)
    handles = [
        Line2D([], [], marker="s", ls="", color="black", label="Flagged"),
        Line2D([], [], marker="s", ls="", mfc="white", mec="black",
               label="Tested, unflagged"),
        Line2D([], [], marker="x", ls="", color="black",
               label="No qualifying zero window")]
    fig.legend(handles=handles, loc="lower center", ncol=3, frameon=False,
               fontsize=9.5, handletextpad=.4, columnspacing=1,
               bbox_to_anchor=(.5, .006))
    fig.subplots_adjust(left=.105, right=.985, bottom=.15, top=.90)
    save_figure(fig, 2)

    fig, axes = plt.subplots(3, 2, figsize=(6.5, 6.5), sharex=True, sharey=False)
    cases += [("EL", "I04"), ("HU", "I03")]
    case_labels += ["Greece: SPADs", "Hungary: signalling failure"]
    data = outputs["figure_3_data"]
    for j, (axis, (country, indicator), label) in enumerate(
            zip(axes.ravel(), cases, case_labels)):
        rows = data.query(
            "country==@country and indicator==@indicator").sort_values("year")
        year = rows.year.to_numpy()
        count = rows["count"].to_numpy()
        maximum = np.nanmax(count)
        axis.axhline(0, color="black", lw=.6, zorder=0)
        axis.plot(year, count, color="black", lw=1, marker="o", ms=3.2,
                  mfc="black", zorder=2)
        zero = count == 0
        axis.scatter(year[zero], count[zero], s=25, facecolor="white",
                     edgecolor="black", linewidths=.8, zorder=3)
        missing_years = year[~np.isfinite(count)]
        axis.scatter(missing_years, np.full(len(missing_years), -.075 * maximum),
                     s=30, marker="x", color="black", linewidths=1,
                     zorder=3)
        role = "Primary" if j < 2 else "Exploratory" if j < 4 else "Descriptive"
        axis.set_title(f"({chr(65+j)}) {label}", loc="left", fontsize=10, pad=8)
        axis.text(.98, .99, role, transform=axis.transAxes, ha="right",
                  va="top", fontsize=9.5, color="black")
        axis.set_ylim(-.13 * maximum, 1.20 * maximum)
        axis.set_xlim(2009.7, 2024.3)
        ticks = MaxNLocator(nbins=4, integer=True, min_n_ticks=3).tick_values(
            0, 1.20 * maximum)
        axis.set_yticks(ticks[(ticks >= 0) & (ticks <= 1.20 * maximum)])
        axis.set_ylabel("Annual count")
        axis.spines["bottom"].set_visible(False)
        if j >= 4:
            axis.set_xlabel("Year")
        axis.set_xticks([2010, 2015, 2020, 2024])
        axis.tick_params(labelsize=10)
    handles = [
        Line2D([], [], color="black", marker="o", lw=1, ms=3.2,
               label="Reported count"),
        Line2D([], [], ls="", marker="o", mfc="white", mec="black",
               label="Reported zero"),
        Line2D([], [], ls="", marker="x", color="black",
               label="Missing year")]
    fig.legend(handles=handles, loc="lower center", ncol=3, frameon=False,
               fontsize=10, bbox_to_anchor=(.5, .008), columnspacing=1.5)
    fig.subplots_adjust(left=.105, right=.965, bottom=.14, top=.93,
                        hspace=.61, wspace=.40)
    save_figure(fig, 3)

