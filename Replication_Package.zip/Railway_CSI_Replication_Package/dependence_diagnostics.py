"""Observed lag-one dependence diagnostics for the CSI count panel.

Marginal randomized-quantile correlations describe the fitted residuals.
Adjacent-pair Gaussian-copula likelihoods estimate a different, latent
correlation, accounting for the intervals induced by discrete counts.
Both are descriptive fits conditional on the supplied NB2 dispersions.
Country-block resampling retains all indicators and years in each country.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from numpy.polynomial.legendre import leggauss
from scipy.optimize import minimize_scalar
from scipy.special import ndtr, ndtri
from scipy.stats import nbinom, poisson
from audit_engine import load_panel, fit_nb2
from report_outputs import read_source
from dispersion_sensitivity import profiled_rates, nb_loglik


def marginal_fits(panel: dict, fit: dict, trend: bool) -> tuple[np.ndarray, pd.DataFrame]:
    """Fit observed full-series means; the primary alpha remains fixed."""
    means = fit['means'].copy()
    rows = []
    for ii, indicator in enumerate(panel['indicators']):
        for cc, country in enumerate(panel['countries']):
            valid = panel['valid'][ii, cc]
            y = panel['counts'][ii, cc, valid]
            e = panel['exposure'][ii, cc, valid]
            slope = 0.0
            converged = True
            boundary_fallback = False
            if not valid.any() or y.sum() == 0:
                rate = 0.0
            elif not trend:
                rate = float(fit['rates'][ii, cc])
            else:
                t = panel['years'][valid].astype(float)
                t -= t.mean()
                alpha = float(fit['alpha'][ii])
                def ll(s: float) -> float:
                    tilted = e * np.exp(s * t)
                    r = profiled_rates(y[None, :], tilted[None, :], alpha)[0]
                    return float(nb_loglik(y, r * tilted, alpha).sum())
                opt = minimize_scalar(lambda s: -ll(s), bounds=(-5.0, 5.0),
                                      method='bounded', options={'xatol': 1e-9})
                slope = float(opt.x)
                converged = bool(opt.success and abs(slope) < 4.99)
                if not opt.success:
                    raise RuntimeError(f'Trend fit failed for {country}-{indicator}')
                if not converged:
                    # An endpoint-only positive count can have no finite slope MLE.
                    # Retain its constant-rate mean and report that fallback.
                    slope = 0.0
                    boundary_fallback = True
                tilted = e * np.exp(slope * t)
                rate = (float(fit['rates'][ii, cc]) if boundary_fallback else
                        float(profiled_rates(y[None, :], tilted[None, :], alpha)[0]))
                means[ii, cc] = 0.0
                means[ii, cc, valid] = rate * tilted
            for tt in np.flatnonzero(valid):
                rows.append(dict(mean_model='log_linear' if trend else 'constant_rate',
                    country=country, indicator=indicator, year=int(panel['years'][tt]),
                    count=float(panel['counts'][ii, cc, tt]),
                    exposure=float(panel['exposure'][ii, cc, tt]),
                    mean=float(means[ii, cc, tt]), alpha=float(fit['alpha'][ii]),
                    annual_slope=slope, informative=bool(rate > 0), converged=converged,
                    constant_rate_fallback=boundary_fallback))
    return means, pd.DataFrame(rows)


def distribution_bounds(y: np.ndarray, mu: np.ndarray, alpha: float):
    if alpha > 0:
        d = nbinom(1.0 / alpha, 1.0 / (1.0 + alpha * mu))
    else:
        d = poisson(mu)
    lower = d.cdf(y - 1)
    upper = d.cdf(y)
    mass = d.pmf(y)
    survival = d.sf(y)
    if np.any(mass <= 0):
        raise FloatingPointError('An observed NB2 mass underflowed')
    return lower, upper, mass, survival


def corr_sums(s: np.ndarray) -> np.ndarray:
    """Pearson correlation from n, sumx, sumy, sumx2, sumy2, sumxy."""
    n, sx, sy, sxx, syy, sxy = np.moveaxis(s, -1, 0)
    vx, vy = sxx - sx * sx / n, syy - sy * sy / n
    return (sxy - sx * sy / n) / np.sqrt(vx * vy)


def quantile_diagnostic(panel, means, alpha, repetitions=512, seed=20261024):
    """Average correlations across independent marginal PIT randomisations.

    Repeated appearances of an observation in adjacent pairs use the same
    randomized score. All-zero series, missing years and gaps are excluded.
    Returns per-country sufficient statistics averaged over randomisations.
    """
    ni, nc, nt = means.shape
    sums = np.zeros((repetitions, ni, nc, 6))
    pair_n = np.zeros((ni, nc), int)
    bounds = []
    for ii in range(ni):
        ii_bounds = []
        for cc in range(nc):
            valid = panel['valid'][ii, cc] & (means[ii, cc] > 0)
            positions = np.flatnonzero(valid[:-1] & valid[1:])
            pair_n[ii, cc] = len(positions)
            if not len(positions):
                ii_bounds.append(None)
                continue
            observed = np.flatnonzero(valid)
            y = panel['counts'][ii, cc, valid]
            lo, hi, mass, sf = distribution_bounds(y, means[ii, cc, valid], float(alpha[ii]))
            rng = np.random.default_rng(np.random.SeedSequence([seed, ii, cc]))
            u = rng.random((repetitions, len(y)))
            # Work from the upper tail when appropriate to preserve precision.
            z = np.where(hi[None, :] <= 0.5,
                ndtri(np.clip(lo[None, :] + u * mass[None, :], 1e-15, 1-1e-15)),
                -ndtri(np.clip(sf[None, :] + (1-u) * mass[None, :], 1e-15, 1-1e-15)))
            full = np.full((repetitions, nt), np.nan)
            full[:, observed] = z
            x, q = full[:, positions], full[:, positions+1]
            sums[:, ii, cc, 0] = len(positions)
            sums[:, ii, cc, 1] = x.sum(axis=1)
            sums[:, ii, cc, 2] = q.sum(axis=1)
            sums[:, ii, cc, 3] = (x*x).sum(axis=1)
            sums[:, ii, cc, 4] = (q*q).sum(axis=1)
            sums[:, ii, cc, 5] = (x*q).sum(axis=1)
            ii_bounds.append((observed, positions, lo, hi, mass, sf))
        bounds.append(ii_bounds)
    return sums, pair_n, bounds


def pair_arrays(panel, means, alpha):
    """Discrete marginal intervals for complete adjacent calendar pairs."""
    rows = []
    for ii, ind in enumerate(panel['indicators']):
        for cc, country in enumerate(panel['countries']):
            valid = panel['valid'][ii, cc] & (means[ii, cc] > 0)
            pos = np.flatnonzero(valid[:-1] & valid[1:])
            if not len(pos):
                continue
            for t in pos:
                lo, hi, mass, sf = distribution_bounds(
                    panel['counts'][ii, cc, [t,t+1]], means[ii, cc, [t,t+1]], float(alpha[ii]))
                rows.append((ii, cc, t, *lo, *hi, *mass, *sf))
    a = np.array(rows)
    return dict(ii=a[:,0].astype(int), cc=a[:,1].astype(int), tt=a[:,2].astype(int),
                lo1=a[:,3], lo2=a[:,4], hi1=a[:,5], hi2=a[:,6],
                m1=a[:,7], m2=a[:,8], sf1=a[:,9], sf2=a[:,10])


def copula_country_grid(pairs, ni, nc, grid, quadrature=96):
    """Adjacent-pair log likelihood, omitting fixed marginal mass constants.

    Gauss-Legendre quadrature integrates over the first discrete PIT interval.
    No jitter is used in the latent correlation fit. A correlation of zero
    returns an exact independence likelihood contribution of zero.
    """
    nodes, weights = leggauss(quadrature)
    nodes, weights = (nodes + 1)/2, weights/2
    u = pairs['lo1'][:,None] + pairs['m1'][:,None] * nodes
    sf = pairs['sf1'][:,None] + pairs['m1'][:,None] * (1-nodes)
    x = np.where(pairs['hi1'][:,None] <= 0.5,
        ndtri(np.clip(u,1e-15,1-1e-15)), -ndtri(np.clip(sf,1e-15,1-1e-15)))
    # Probability endpoints are exact infinities at 0 and 1.
    a = np.where(pairs['lo2'] > 0.5, -ndtri(pairs['sf2'] + pairs['m2']), ndtri(pairs['lo2']))
    b = np.where(pairs['hi2'] > 0.5, -ndtri(pairs['sf2']), ndtri(pairs['hi2']))
    g = np.zeros((ni, nc, len(grid)))
    for kk, rho in enumerate(grid):
        if abs(rho) < 1e-12:
            continue
        scale = np.sqrt(1 - rho*rho)
        aa = (a[:,None] - rho*x)/scale
        bb = (b[:,None] - rho*x)/scale
        prob = np.where(aa > 0, ndtr(-aa) - ndtr(-bb), ndtr(bb) - ndtr(aa))
        cond_mass = np.maximum(prob @ weights, np.finfo(float).tiny)
        logrel = np.log(cond_mass) - np.log(pairs['m2'])
        np.add.at(g[:,:,kk], (pairs['ii'],pairs['cc']), logrel)
    return g


def grid_argmax(curve, grid):
    """Parabolic refinement of a bounded uniform-grid maximum."""
    curve=np.asarray(curve)
    k=np.argmax(curve,axis=-1)
    mid=np.clip(k,1,len(grid)-2)
    f0=np.take_along_axis(curve,(mid-1)[...,None],axis=-1)[...,0]
    f1=np.take_along_axis(curve,mid[...,None],axis=-1)[...,0]
    f2=np.take_along_axis(curve,(mid+1)[...,None],axis=-1)[...,0]
    denominator=f0-2*f1+f2
    adjustment=np.divide(0.5*(f0-f2), denominator,
                         out=np.zeros_like(f0), where=np.abs(denominator)>1e-20)
    adjustment=np.clip(adjustment,-1,1)
    refined=grid[mid]+adjustment*(grid[1]-grid[0])
    return np.where((k==0)|(k==len(grid)-1),grid[k],refined)


def run(data: Path, output: Path, repetitions=512, bootstraps=2000,
        seed=20261024, quadrature=96):
    output=Path(output); output.mkdir(parents=True,exist_ok=True)
    panel=load_panel(read_source(data));fit=fit_nb2(panel)
    ni,nc,_=panel['counts'].shape
    grid=np.linspace(-0.6,0.95,311)
    rng=np.random.default_rng(seed+100)
    samples=rng.integers(0,nc,(bootstraps,nc))
    weights=np.array([np.bincount(s,minlength=nc) for s in samples],float)
    summaries=[];margins=[];bootstrap_rows=[]
    for model_number, trend in enumerate([False,True]):
        means,margin=marginal_fits(panel,fit,trend)
        margins.append(margin)
        sums,pair_n,_=quantile_diagnostic(panel,means,fit['alpha'],repetitions,seed+model_number)
        pairs=pair_arrays(panel,means,fit['alpha'])
        curves=copula_country_grid(pairs,ni,nc,grid,quadrature)
        for group,ii in [('All indicators',None),*[(v,i) for i,v in enumerate(panel['indicators'])]]:
            country_sums=sums.sum(axis=1) if ii is None else sums[:,ii]
            country_curve=curves.sum(axis=0) if ii is None else curves[ii]
            count=pair_n.sum(axis=0) if ii is None else pair_n[ii]
            # Average sufficient statistics integrates over PIT randomisation.
            mean_sums=country_sums.mean(axis=0)
            r=float(corr_sums(mean_sums.sum(axis=0)))
            r_random=corr_sums(country_sums.sum(axis=1))
            r_boot=corr_sums(weights@mean_sums)
            rho=float(grid_argmax(country_curve.sum(axis=0),grid))
            rho_boot=grid_argmax(weights@country_curve,grid)
            m='log_linear' if trend else 'constant_rate'
            summaries.append(dict(mean_model=m,indicator=group,
                informative_series=int((pair_n>0).sum()) if ii is None else int((pair_n[ii]>0).sum()),
                countries=int((count>0).sum()),adjacent_pairs=int(count.sum()),
                quantile_residual_r=r,
                r_bootstrap_low=float(np.quantile(r_boot,.025)),r_bootstrap_high=float(np.quantile(r_boot,.975)),
                r_randomisation_low=float(np.quantile(r_random,.025)),r_randomisation_high=float(np.quantile(r_random,.975)),
                pairwise_latent_rho=rho,
                rho_bootstrap_low=float(np.quantile(rho_boot,.025)),rho_bootstrap_high=float(np.quantile(rho_boot,.975)),
                bootstrap_replicates=bootstraps,pit_repetitions=repetitions,
                quadrature_nodes=quadrature,grid_step=.005))
            bootstrap_rows.extend(dict(mean_model=m,indicator=group,replicate=int(j),
                quantile_residual_r=float(r_boot[j]),pairwise_latent_rho=float(rho_boot[j])) for j in range(bootstraps))
        print(m,[(s['indicator'],round(s['quantile_residual_r'],3),round(s['pairwise_latent_rho'],3)) for s in summaries if s['mean_model']==m],flush=True)
    summary=pd.DataFrame(summaries)
    summary.to_csv(output/'dependence_diagnostics.csv',index=False)
    pd.concat(margins,ignore_index=True).to_csv(output/'dependence_fitted_margins.csv',index=False)
    pd.DataFrame(bootstrap_rows).to_csv(output/'dependence_bootstrap.csv',index=False)
    return summary


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    root=Path(__file__).resolve().parent
    parser.add_argument('--data',type=Path,default=root/'data')
    parser.add_argument('--output',type=Path,default=root/'reproduced_results')
    args=parser.parse_args()
    config=json.loads((root/'analysis_config.json').read_text()).get('observed_dependence',{})
    run(args.data,args.output,**config)
