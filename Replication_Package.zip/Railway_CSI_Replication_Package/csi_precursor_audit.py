"""Reproduce the manuscript tables, figures, and full-panel calibration."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from audit_engine import load_panel, fit_nb2, fit_table, run_audit, probability_text
from calibration import calibrate
from dispersion_sensitivity import dispersion_outputs, case_sensitivities, baseline_trend_diagnostics
from serial_stress import stress_calibration, observed_serial_sensitivity
from calendar_diagnostics import run as calendar_diagnostics
from dependence_diagnostics import run as dependence_diagnostics
from evidence_summaries import run as evidence_summaries
from report_outputs import (read_source, descriptive_outputs, additional_sensitivities,
                            supplemental_metrics, make_figures)


def bh_probabilities(frame):
    logp = np.minimum(0, frame.log_raw_p.to_numpy()
                      + np.log(np.maximum(1, frame.eligible_starts.to_numpy())))
    order = np.argsort(logp, kind="stable")
    ranked = logp[order] + np.log(len(logp)/np.arange(1,len(logp)+1))
    adjusted = np.minimum(0,np.minimum.accumulate(ranked[::-1])[::-1])
    values = np.empty(len(logp));values[order]=np.exp(adjusted)
    return values


def main():
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data",type=Path,default=root/"data")
    parser.add_argument("--output",type=Path,default=root/"reproduced_results")
    parser.add_argument("--config",type=Path,default=root/"analysis_config.json")
    parser.add_argument("--workers",type=int,default=6)
    args = parser.parse_args()
    config=json.loads(args.config.read_text(encoding="utf-8"))
    output=args.output.resolve();output.mkdir(parents=True,exist_ok=True)
    source=read_source(args.data)
    panel=load_panel(source,start_year=config["analysis_start"],end_year=config["analysis_end"])
    fit=fit_nb2(panel)
    fit_table(panel,fit).to_csv(output/"indicator_dispersion.csv",index=False)
    scans={}
    for duration in [config["primary_duration"],*config["exploratory_durations"]]:
        frame,_=run_audit(panel,baseline_years=config["baseline_years"],window_years=duration,
                          fit=fit,inner_draws=config["nb_simulations"],seed=config["observed_seed"],
                          chunk_size=config["simulation_chunk_size"])
        frame.insert(0,"window_years",duration)
        frame.insert(0,"baseline_years",config["baseline_years"])
        frame.insert(0,"analysis_role","Primary" if duration==5 else "Exploratory")
        frame["poisson_bh_q"]=bh_probabilities(frame)
        scans[duration]=frame
    all_scans=pd.concat([scans[d] for d in sorted(scans)],ignore_index=True)
    all_scans.to_csv(output/"audit_results.csv",index=False)
    case_keys={("BG","I02"),("PL","I03"),("RO","I04"),("BG","I06")}
    cases=all_scans[[tuple(x) in case_keys for x in all_scans[["country","indicator"]].to_numpy()]].copy()
    cases["poisson_holm_p_text"]=[probability_text(p) for p in cases.log_poisson_holm_p]
    cases.to_csv(output/"table_S11_final_probabilities.csv",index=False)
    descriptive=descriptive_outputs(source,panel,scans,output)
    supplemental_metrics(panel,scans,descriptive["conservative_screen"],output)
    additional_sensitivities(source,scans,output,draws=config["nb_simulations"],seed=config["sensitivity_seed"])
    make_figures(descriptive,scans,output/"figures")
    primary=scans[5][scans[5].final_flag]
    print("Primary flags: "+"; ".join(primary.country+"-"+primary.indicator),flush=True)
    summary=calibrate(panel,output,panels=config["null_panels_per_model"],draws=config["nb_simulations"],
                      workers=args.workers,seed=config["calibration_seed"],
                      chunk_size=config["simulation_chunk_size"])
    final=summary[summary.procedure=="final_intersection"]
    print(final[["null_model","panels_with_flag","panels","familywise_flag_rate","ci95_low","ci95_high"]].to_string(index=False),flush=True)
    parameter=config["parameter_sensitivity"]
    extra_fit,intervals,_=dispersion_outputs(panel,output)
    case_sensitivities(panel,extra_fit,intervals,output,
                       draws=parameter["parameter_sensitivity_draws"],
                       seed=parameter["parameter_sensitivity_seed"],
                       primary_upper_draws=parameter["primary_alpha_upper_draws"])
    baseline_trend_diagnostics(panel,extra_fit,output)
    serial=config["serial_sensitivity"]
    stress_calibration(panel,output,rhos=serial["serial_latent_rhos"],
                       panels=serial["serial_null_panels_per_rho"],
                       draws=serial["serial_inner_draws"],workers=args.workers,
                       seed=serial["serial_calibration_seed"])
    observed_serial_sensitivity(panel,output,
                                rhos=tuple(r for r in serial["serial_latent_rhos"] if r>0),
                                draws=serial["serial_observed_draws"],seed=serial["serial_observed_seed"])
    pandemic=config["pandemic_sensitivity"]
    calendar_diagnostics(args.data,output/"audit_results.csv",output,
                         inner_draws=pandemic["inner_draws"],seed=pandemic["seed"])
    dependence_diagnostics(args.data, output, **config["observed_dependence"])
    evidence_summaries(args.data, output)



if __name__=="__main__":
    main()
