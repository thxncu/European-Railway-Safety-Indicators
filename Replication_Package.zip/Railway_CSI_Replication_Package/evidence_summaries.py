"""Reproduce comparison coverage, trend probabilities and aggregate scenarios.

Scenario counts are analytical comparisons. Input register values are retained.
The baseline-rate scenario is distinct from the documented event minimum.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from audit_engine import load_panel, fit_nb2, scan_panel, run_audit
from report_outputs import read_source, source_series
from dispersion_sensitivity import baseline_trend_diagnostics, profiled_rates


def run(data: Path, output: Path) -> None:
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    source=read_source(data);panel=load_panel(source);fit=fit_nb2(panel)
    scan=scan_panel(panel,window_years=5)
    complete=int((scan.eligible_starts>0).sum())
    zero=int(scan.window_start.notna().sum())
    screen=scan.log_raw_p.to_numpy()+np.log(np.maximum(1,scan.eligible_starts.to_numpy()))<=np.log(.05/168)
    detail=[('National country-indicator series',168,'28 countries x six indicators'),
            ('At least one complete five-plus-five-year comparison',complete,'Observed counts and positive exposure in all ten years'),
            ('A qualifying five-year zero window',zero,'At least one baseline event'),
            ('Selected zero comparison passes conservative screen',int(screen.sum()),'Within-series probability at most 0.05/168'),
            ('Selected zero comparison below conservative screen',zero-int(screen.sum()),'Complement among selected zero-window comparisons')]
    full_scan,_=run_audit(panel,fit=fit,window_years=5,inner_draws=200000,seed=20261009)
    detail.append(('Final combined model flags',int(full_scan.final_flag.sum()),'Both 168-series Holm probabilities at most 0.05'))
    pd.DataFrame(detail,columns=['stage','series','criterion']).to_csv(output/'comparison_coverage.csv',index=False)
    trends=baseline_trend_diagnostics(panel,fit,output)
    annual=[]
    for row in trends.itertuples():
        ii=panel['indicators'].index(row.indicator);cc=panel['countries'].index(row.country)
        selected=scan_panel(panel,window_years=row.window_years).query('country==@row.country and indicator==@row.indicator').iloc[0]
        years=panel['years'];keep=(years>=row.baseline_start)&(years<=row.baseline_end)
        t0=float(years[keep].mean())
        e=panel['exposure'][ii,cc,keep];y=panel['counts'][ii,cc,keep]
        tilted=e*np.exp(row.slope_per_year*(years[keep]-t0))
        rate=profiled_rates(y[None,:],tilted[None,:],row.fixed_pooled_alpha)[0]
        window=(years>=selected.window_start)&(years<=selected.window_end)
        mu=rate*panel['exposure'][ii,cc,window]*np.exp(row.slope_per_year*(years[window]-t0))
        logp=-np.log1p(row.fixed_pooled_alpha*mu)/row.fixed_pooled_alpha
        if not np.isclose(np.exp(logp.sum()),row.conditional_window_zero_probability,rtol=1e-8,atol=0):
            raise AssertionError('Trend zero probability mismatch')
        for t,m,l in zip(years[window],mu,logp):
            annual.append(dict(country=row.country,indicator=row.indicator,window_years=row.window_years,
                year=int(t),mean=float(m),alpha=row.fixed_pooled_alpha,
                annual_zero_probability=float(np.exp(l)),annual_log_zero_probability=float(l)))
    pd.DataFrame(annual).to_csv(output/'baseline_trend_predictions.csv',index=False)

    country_rows=[]
    periods=[(2015,2019),(2020,2023)]
    for start,end in periods:
        years=np.arange(start,end+1)
        for country in panel['countries']:
            y=source_series(source,country,'I04',years)
            e=source_series(source,country,'R01',years)
            valid=np.isfinite(y)&np.isfinite(e)&(e>0)
            country_rows.append(dict(start_year=start,end_year=end,country=country,
                valid_years=int(valid.sum()),events=float(y[valid].sum()),exposure=float(e[valid].sum())))
    country_frame=pd.DataFrame(country_rows)
    country_frame.to_csv(output/'aggregate_country_periods.csv',index=False)
    catalogue=(Path(data)/'event_evidence.csv' if Path(data).is_dir() else Path(__file__).resolve().parent/'data/event_evidence.csv')
    events=pd.read_csv(catalogue)
    qualifying=events[(events['country']=='Romania') &
                      (events['classification']=='Qualifying event documented')].copy()
    qualifying['event_date']=pd.to_datetime(qualifying['event_date'])
    qualifying=qualifying[(qualifying.event_date.dt.year>=2020)&
                          (qualifying.event_date.dt.year<=2023)]
    confirmed=qualifying.drop_duplicates(['event_date','event_location'])
    minimum=int(len(confirmed))
    if minimum != 7:
        raise AssertionError('Event catalogue differs from the reported minimum')
    ro=country_frame.query("country=='RO'")
    baseline=ro[ro.start_year==2015].iloc[0]
    later=ro[ro.start_year==2020].iloc[0]
    rate=float(baseline.events/baseline.exposure)
    expected=float(rate*later.exposure)
    y2024=float(source['values']['RO|I04|2024']); e2024=float(source['values']['RO|R01|2024'])
    pd.DataFrame([dict(baseline_start=2015,baseline_end=2019,baseline_events=baseline.events,
        baseline_exposure_million_train_km=baseline.exposure,baseline_rate_per_million=rate,
        candidate_start=2020,candidate_end=2023,candidate_reported_events=later.events,
        candidate_exposure_million_train_km=later.exposure,
        unchanged_baseline_rate_expected_events=expected,documented_minimum_events=minimum,
        reported_events_2024=y2024,exposure_2024_million_train_km=e2024,
        reported_rate_2024_per_million=y2024/e2024,
        baseline_to_2024_reported_rate_ratio=rate/(y2024/e2024))]).to_csv(output/'romania_rate_scenario.csv',index=False)
    scenarios=[]
    for label,exclude,increment in [
        ('Reported study aggregate',False,0.0),
        ('Reported aggregate excluding Romania',True,0.0),
        ('Add seven documented events',False,float(minimum)),
        ('Unchanged Romanian baseline-rate scenario',False,expected)]:
        f=country_frame[country_frame.country!='RO'] if exclude else country_frame
        b=f[f.start_year==2015];a=f[f.start_year==2020]
        by=float(b.events.sum());be=float(b.exposure.sum())
        ay=float(a.events.sum()+increment);ae=float(a.exposure.sum())
        br=1000*by/be;ar=1000*ay/ae
        scenarios.append(dict(scenario=label,baseline_events=by,baseline_exposure_million_train_km=be,
            candidate_events=ay,candidate_exposure_million_train_km=ae,
            baseline_rate_per_billion_train_km=br,candidate_rate_per_billion_train_km=ar,
            percent_change=100*(ar/br-1),added_scenario_events=increment))
    pd.DataFrame(scenarios).to_csv(output/'aggregate_rate_scenarios.csv',index=False)
    print(pd.DataFrame(scenarios).to_string(index=False),flush=True)


if __name__=='__main__':
    root=Path(__file__).resolve().parent
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data',type=Path,default=root/'data')
    parser.add_argument('--output',type=Path,default=root/'reproduced_results')
    args=parser.parse_args();run(args.data,args.output)
