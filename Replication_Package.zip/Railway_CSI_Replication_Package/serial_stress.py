"""Complete-pipeline stress calibration with serially dependent NB2 counts.

A Gaussian AR(1) copula preserves the fitted annual NB2 marginal distribution.
The supplied rho values describe latent Gaussian dependence, not count
autocorrelation. The analysis fitted to each generated panel remains the
independent-count five-year audit; it refits its rates and dispersions.
"""
from __future__ import annotations

import argparse
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np
import pandas as pd
from scipy.special import ndtr
from scipy.stats import nbinom, poisson

from audit_engine import (load_panel, fit_nb2, make_geometry, scan_arrays, scan_panel,
                          mc_scan_probability, holm_log, binomial_interval)
from report_outputs import read_source

_PANEL = _GEOMETRY = _CONFIG = None


def invert_nb_cdf(uniform, means, alphas):
    """Invert fitted marginal CDFs for a (draw,series,year) uniform array."""
    if np.any((uniform<=0)|(uniform>=1)):
        raise RuntimeError('Gaussian transform reached a floating-point endpoint')
    number,n,t=uniform.shape
    y=np.zeros((number,n,t),dtype=np.int64)
    for j in range(n):
        alpha=alphas[j]
        for year in range(t):
            mu=means[j,year]
            if mu==0:
                continue
            u=uniform[:,j,year]
            distribution=poisson(mu) if alpha==0 else nbinom(1/alpha,1/(1+alpha*mu))
            largest=int(distribution.ppf(float(u.max())))
            cdf=distribution.cdf(np.arange(largest+1))
            y[:,j,year]=np.searchsorted(cdf,u,side='left')
            if np.any(y[:,j,year]>largest):
                raise RuntimeError('Inverse-CDF lookup did not cover generated uniforms')
    return y


def correlated_panels(panel, truth, rho, panels=2000, seed=20261022):
    """Generate stationary Gaussian-copula NB2 panels by exact CDF inversion.

    CDF lookup lengths cover each generated maximum uniform variate. This
    produces the same quantiles as inverse-CDF sampling without tail clipping.
    Separate country-indicator series remain independent. Latent states advance
    through every calendar year, including years masked as missing in analysis.
    """
    if not 0 <= rho < 1:
        raise ValueError('rho must be in [0,1)')
    shape=panel['counts'].shape
    n,t=int(np.prod(shape[:-1])),shape[-1]
    z=np.empty((panels,n,t))
    code=int(round(rho*1000))
    scale=np.sqrt(1-rho*rho)
    for index in range(panels):
        rng=np.random.default_rng(np.random.SeedSequence([seed,code,index,0]))
        innovations=rng.standard_normal((n,t))
        z[index,:,0]=innovations[:,0]
        for year in range(1,t):
            z[index,:,year]=rho*z[index,:,year-1]+scale*innovations[:,year]
    uniform=ndtr(z)
    means=truth['means'].reshape(n,t)
    nc=len(panel['countries'])
    y=invert_nb_cdf(uniform,means,np.repeat(truth['alpha'],nc))
    return y.reshape((panels,*shape))


def correlated_scan_probability(mean,alpha,geometry,j,observed_log_t,rho,
                                draws=200000,seed=20261023,chunk_size=20000):
    """Full-scan tail probability under a specified serial-dependence stress."""
    rng=np.random.default_rng(np.random.SeedSequence([seed,int(round(rho*1000)),int(j)]))
    starts=geometry['starts'];b=geometry['baseline_years'];w=geometry['window_years']
    eligible=geometry['eligible'][j];logfraction=geometry['logfraction'][j]
    hits=0;t=len(mean)
    for begin in range(0,draws,chunk_size):
        number=min(chunk_size,draws-begin)
        z=rng.standard_normal((number,1,t))
        for year in range(1,t):
            z[:,:,year]=rho*z[:,:,year-1]+np.sqrt(1-rho*rho)*z[:,:,year]
        simulated=invert_nb_cdf(ndtr(z),np.asarray(mean)[None,:],np.array([alpha]))[:,0,:]
        cumulative=np.pad(np.cumsum(simulated,axis=1),((0,0),(1,0)))
        baseline=cumulative[:,starts]-cumulative[:,starts-b]
        candidate=cumulative[:,starts+w]-cumulative[:,starts]
        zero=eligible[None,:]&(baseline>0)&(candidate==0)
        logt=np.min(np.where(zero,baseline*logfraction[None,:],0.),axis=1)
        hits+=int(np.count_nonzero(logt<=observed_log_t))
    return (hits+1)/(draws+1),hits


def observed_serial_sensitivity(panel,output,rhos=(.3,.6),draws=200000,seed=20261023):
    fit=fit_nb2(panel)
    geometry=make_geometry(panel,5,5)
    scan=scan_panel(panel)
    n,t=geometry['valid'].shape
    means=fit['means'].reshape(n,t);nc=len(panel['countries'])
    rows=[]
    for rho in rhos:
        pnb=np.ones(n);detail=[]
        for j in np.flatnonzero(scan.poisson_flag):
            pnb[j],hits=correlated_scan_probability(means[j],fit['alpha'][j//nc],geometry,int(j),
                scan.loc[j,'log_raw_p'],rho,draws,seed)
            low,high=binomial_interval(hits,draws)
            detail.append(dict(latent_rho=rho,country=scan.loc[j,'country'],
                indicator=scan.loc[j,'indicator'],series_index=int(j),nb_exceedances=hits,
                nb_draws=draws,nb_raw_p=pnb[j],nb_tail_mc_ci95_low=low,nb_tail_mc_ci95_high=high,
                poisson_holm_p=scan.loc[j,'poisson_holm_p']))
        adjusted=np.exp(holm_log(np.log(pnb)))
        for row in detail:
            row['nb_holm_p']=adjusted[row['series_index']]
            row['final_flag']=bool(row['nb_holm_p']<=.05)
            rows.append(row)
    frame=pd.DataFrame(rows)
    frame.to_csv(Path(output)/'observed_serial_sensitivity.csv',index=False)
    return frame


def initialize_worker(panel,config):
    global _PANEL,_GEOMETRY,_CONFIG
    _PANEL,_CONFIG=panel,config
    _GEOMETRY=make_geometry(panel,5,5)


def evaluate_panel(job):
    rho,index,y=job
    fit=fit_nb2(_PANEL,y)
    if not np.all(fit['converged']):
        raise RuntimeError(f'Dispersion fit failed for rho={rho}, panel={index}')
    scan=scan_arrays(y,_GEOMETRY)
    flat=np.where(_GEOMETRY['valid'],y.reshape(_GEOMETRY['valid'].shape),0)
    cumulative=np.pad(np.cumsum(flat,axis=1),((0,0),(1,0)))
    starts=_GEOMETRY['starts']
    candidate=cumulative[:,starts+5]-cumulative[:,starts]
    simple=np.any(_GEOMETRY['eligible']&(scan['baseline_counts']>=15)&(candidate==0),axis=1)
    candidates=np.flatnonzero(scan['poisson_flag'])
    n,t=_GEOMETRY['valid'].shape
    means=fit['means'].reshape(n,t)
    nc=len(_PANEL['countries'])
    pnb=np.ones(n)
    details=[]
    for j in candidates:
        seed=[_CONFIG['seed'],int(round(rho*1000)),index,1,int(j)]
        pnb[j],hits=mc_scan_probability(means[j],fit['alpha'][j//nc],_GEOMETRY,int(j),
            scan['log_raw_p'][j],draws=_CONFIG['draws'],seed=seed,chunk_size=20000)
        details.append(dict(series_index=int(j),country=_PANEL['countries'][j%nc],
                            indicator=_PANEL['indicators'][j//nc],
                            exceedances=hits,nb_raw_p=pnb[j],
                            observed_log_t=scan['log_raw_p'][j]))
    adjusted=np.exp(holm_log(np.log(pnb)))
    final=scan['poisson_flag']&(adjusted<=.05)
    for detail in details:
        j=detail['series_index']
        detail['nb_holm_p']=adjusted[j]
        detail['final_flag']=bool(final[j])
    row=dict(latent_rho=rho,panel_index=index,poisson_flags=int(scan['poisson_flag'].sum()),
             simple_rule_flags=int(simple.sum()),
             final_flags=int(final.sum()),inner_series_tested=len(candidates),
             final_flag_ids=';'.join(f"{_PANEL['countries'][j%nc]}-{_PANEL['indicators'][j//nc]}"
                                    for j in np.flatnonzero(final)))
    for ii,indicator in enumerate(_PANEL['indicators']):
        row['refitted_alpha_'+indicator]=fit['alpha'][ii]
    row['details']=details
    return row


def summarize(rows):
    output=[]
    for rho in sorted({r['latent_rho'] for r in rows}):
        selected=[r for r in rows if r['latent_rho']==rho]
        n=len(selected)
        for stage,key in [('simple_count_rule','simple_rule_flags'),
                          ('poisson_prefilter','poisson_flags'),('final_intersection','final_flags')]:
            counts=[r[key] for r in selected]
            k=sum(c>0 for c in counts)
            low,high=binomial_interval(k,n)
            output.append(dict(latent_rho=rho,procedure=stage,panels=n,panels_with_flag=k,
                familywise_flag_rate=k/n,ci95_low=low,ci95_high=high,
                ci_method='Clopper-Pearson',mean_flags=float(np.mean(counts)),max_flags=max(counts),
                total_inner_series=sum(r['inner_series_tested'] for r in selected)))
    return pd.DataFrame(output)


def stress_calibration(panel,output,rhos=(0,.3,.6),panels=2000,draws=200000,
                       workers=6,seed=20261022):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    truth=fit_nb2(panel)
    config=dict(draws=draws,seed=seed)
    rows=[]
    for rho in rhos:
        generated=correlated_panels(panel,truth,float(rho),panels,seed)
        jobs=((float(rho),i,generated[i]) for i in range(panels))
        with ProcessPoolExecutor(max_workers=workers,initializer=initialize_worker,
                                 initargs=(panel,config)) as pool:
            rows.extend(pool.map(evaluate_panel,jobs,chunksize=1))
        print(summarize(rows).to_string(index=False),flush=True)
    summary=summarize(rows)
    summary.to_csv(output/'serial_stress_summary.csv',index=False)
    pd.DataFrame([{k:v for k,v in r.items() if k!='details'} for r in rows]).to_csv(
        output/'serial_stress_panels.csv',index=False)
    details=[]
    for row in rows:
        details.extend(dict(latent_rho=row['latent_rho'],panel_index=row['panel_index'],**detail)
                       for detail in row['details'])
    pd.DataFrame(details).to_csv(output/'serial_stress_inner_checks.csv',index=False)
    return summary


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--panels',type=int,default=2000)
    parser.add_argument('--draws',type=int,default=200000)
    parser.add_argument('--workers',type=int,default=6)
    parser.add_argument('--rhos',type=float,nargs='+',default=[0,.3,.6])
    parser.add_argument('--seed',type=int,default=20261022)
    parser.add_argument('--observed-only',action='store_true')
    args=parser.parse_args()
    panel=load_panel(read_source(args.data))
    args.output.mkdir(parents=True,exist_ok=True)
    if not args.observed_only:
        stress_calibration(panel,args.output,args.rhos,args.panels,args.draws,args.workers,args.seed)
    print(observed_serial_sensitivity(panel,args.output,tuple(r for r in args.rhos if r>0),args.draws).to_string(index=False))
