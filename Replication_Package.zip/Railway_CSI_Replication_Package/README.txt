Screening Limits and Event Record Verification of Reported Zeros in European Railway Safety Indicators
Reviewer replication package

Run the analysis

Use Python 3.12 or later and the dependency versions in requirements.txt. From this directory, run:

    python -m pip install -r requirements.txt
    python csi_precursor_audit.py --data data --output reproduced_results --workers 6

The command creates all scientific result CSVs, all model sensitivities,
and three figures in PNG and PDF formats in
reproduced_results/. The supplied counterparts are in results/. No external
download is needed. The --data argument also accepts an ERA source workbook
containing sheets Table 0, Table 3, and Table 6. The number of worker processes
can be reduced; worker count does not change the random streams.

Data and study design

The three source CSVs contain the European Union Agency for Railways (ERA)
Common Safety Indicators (CSI) release covering 2006-2024. The release was last
updated on 14 January 2026. The analysis uses 28 countries, excludes the Channel
Tunnel aggregate, and uses 2010-2024 for the primary panel. An exploratory
analysis extends the panel to 2006. Source URLs, document versions, relevant
pages or cells, and available document SHA-256 values appear in
data/source_catalog.csv. The event evidence supporting the Romania comparison
and the reporting provenance of the Polish comparison appear in
data/event_evidence.csv.

The primary design compares a complete five-year candidate zero window with
its immediately preceding five-year baseline. Three-, four-, six-, and
seven-year candidate windows use five-year baselines and are exploratory.
Each specification receives its own within-series and across-series
corrections. The union of flags across durations is not a jointly adjusted
primary discovery set.

Counts remain distinct from missing values. Every year in the baseline and
candidate window must contain an observed nonnegative count and a positive
observed exposure. A missing calendar year interrupts eligibility. I01-I03
use R03 track-kilometres; I04-I06 use R01 million train-kilometres. R08 line-
kilometres is used in exposure sensitivity analysis. Both R03 and R08 are
measured in kilometres, not millions. DATA_DICTIONARY.txt describes these
variables and the output fields.

Statistical procedure

For each eligible complete calendar position, the scan compares a positive
baseline count with a candidate window containing only zeros. The exact
conditional Poisson probability is (E_baseline / (E_baseline + E_window))
raised to the baseline count. The statistic T is the smallest raw probability
over these zero windows; T=1 when none exists. The selected window is the
earliest minimizer. The within-series Bonferroni multiplier is the number of
complete calendar positions, determined before zero-window selection. Holm
adjustment then covers all 168 country-indicator series. Ineligible series
remain in that family with probability one.

The fitted negative-binomial model uses Var(Y)=mu+alpha*mu^2 (NB2). Each
country-indicator rate equals its total count divided by its total exposure
over all valid years, including zero years. These rates define fixed annual
means for estimating one dispersion parameter per indicator. Scalar
likelihood optimization uses log(alpha) bounds [-12, 5] and tolerance 1e-8,
with an explicit Poisson boundary comparison. An all-zero country series has
fitted mean zero and constant likelihood; its rows do not enter the reported
dispersion fitting sample size.

Only series passing the Poisson Holm screen receive an NB2 full-scan check.
Each check generates 200,000 series under the fitted NB2 model, reapplies the
complete-window scan, and counts T_simulated <= T_observed. All simulations
enter the denominator, including those without an eligible zero window.
The Monte Carlo probability is (exceedances+1)/(200000+1). Uncomputed NB2
probabilities equal one. Holm adjustment covers all 168 series again. A final
flag requires both adjusted probabilities to be at most 0.05. Probability
comparisons use natural logarithms to retain extremely small probabilities.

Complete-null calibration generates 2,000 full panels under fitted independent
Poisson counts and 2,000 under fitted independent NB2 counts. Every generated
panel retains the observed exposure and missingness pattern. Country rates
and all six dispersions are refitted for every panel. The complete five-year
scan, Poisson prefilter, 200,000-draw NB2 checks, and both 168-series Holm
adjustments are repeated. All 2,000 panels per generating model enter the
denominator. The reported intervals are two-sided 95% Clopper-Pearson
intervals for the proportion of panels containing at least one flag.

This calibration describes the complete-null error rate under the fitted
independent generating models. It does not establish error control for every
combination of true and false nulls, serial dependence, trends, or changing
reporting mechanisms. Matched-accident rate ratios and deletion diagnostics
are descriptive comparisons for selected series; their pointwise intervals
and raw probabilities do not correct for that selection.

Random streams and configuration

analysis_config.json contains the full numerical configuration. The observed
scan seed is 20261009, the calibration seed is 20261010, and the sensitivity
seed is 20261109. Each inner simulation generates at most 20,000 rows per
chunk. NumPy default_rng uses SeedSequence inputs as follows, with zero-based
indicator-major series index j:

  Observed scans: [20261009, baseline_years, window_years, j].
  Outer calibration: [20261010, model_code, panel_index, 0].
  Inner calibration: [20261010, model_code, panel_index, 1, j].

model_code is 100 for Poisson and 200 for NB2; panel_index runs from 0 to 1999.
The exposure sensitivity roots are 20261110 (all R01), 20261111 (all R03), and
20261112 (all R08). Alternative baseline roots are 20261213, 20261215, and
20261217 for four, six, and eight years, respectively. The extended 2006-2024
root is 20261309. Each sensitivity root replaces the first element of the
observed-scan seed list. Sensitivities using an already computed specification
reuse its results. Deterministic descriptive analyses use no random seed.

Expected principal results

The primary five-year flags are BG-I02 and PL-I03. Their NB2 Holm probabilities
are 0.005879970600147 and 0.020039899800501, respectively. Exploratory durations
produce BG-I06 and RO-I04 at three years; BG-I02 and RO-I04 at four years;
and BG-I02 at six and seven years. These are separately corrected results.

In calibration, the Poisson generating model produces 0/2000 panels with a
Poisson-prefilter flag and 0/2000 with a final flag. The NB2 generating model
produces 113/2000 panels with a Poisson-prefilter flag and 23/2000 with a final
flag. There are 118 inner checks in total. The final proportions are 0% and
1.15%, with exact 95% intervals 0-0.184274% and 0.730359-1.720595%.

Files and manuscript relationships

  csi_precursor_audit.py       Command-line entry point and complete workflow.
  audit_engine.py             Data arrays, fits, scans, corrections, NB2 checks.
  calibration.py              Full-panel calibration and binomial intervals.
  report_outputs.py           Source reader, descriptive tables, sensitivities,
                             and three figures.
  analysis_config.json        Design, seeds, simulation sizes, and chunk size.
  requirements.txt           Runtime dependency versions.
  DATA_DICTIONARY.txt         Source variables and scientific output fields.
  LICENSE                     Code, documentation, and derived-result licence;
                             the data-source reuse note also applies.
  checksums.sha256            SHA-256 for every other included file.

  data/Table0.csv             Significant accidents and related CSI categories.
  data/Table3.csv             Precursors and precursor subtypes.
  data/Table6.csv             Exposure denominators.
  data/source_catalog.csv     Sources for Section 3.2 and Table S12, including
                             legal guidance relevant to Table S10.
  data/event_evidence.csv     Event and aggregate evidence for Table S12.
  data/country_scope.csv      The 28 country units and Channel Tunnel exclusion.

The following files are within results/:

  table_1_composition.csv     Main Table 1; supplementary Table S1; Figure 1A.
  table_2_persistence.csv     Main Table 2 and Figure 2.
  audit_results.csv          All 168 series at every duration; main Tables 1-2;
                             supplementary Tables S2, S4a, and S11; Figure 1B.
  conservative_screen.csv   Duration-specific screen for all series;
                             main Tables 1-2 and Figure 1.
  case_diagnostics.csv       Main Table 3 deletion rows and supplementary Table S2:
                             baseline-year deletion and exposure diagnostics.
  matched_accident_rates.csv Supplementary Table S7a: primary windows for primary flags,
                             shortest flagged windows for exploratory cases.
  indicator_dispersion.csv  Supplementary Table S3: alpha, log likelihood,
                             fitting sample size, and optimizer status.
  calibration_summary.csv   Supplementary Table S4 and methods/results text.
  calibration_panels.csv    Panel-level basis for Table S4 (4,000 rows).
  calibration_inner_checks.csv
                             Individual NB2 checks behind Table S4 (118 rows).
  calendar_sensitivity.csv  Calendar-year-adjusted Poisson scans; supplementary
                             Tables S2 and S4a and sensitivity text.
  sensitivity_summary.csv   Supplementary Tables S5-S6.
  sensitivity_scans.csv     Series-level basis for Tables S5-S6.
  correction_family_sensitivity.csv
                             Reapplication of corrections to the stored
                             primary probabilities for alternative families;
                             supplementary sensitivity discussion.
  spad_european_context.csv Annual non-Romanian SPAD totals and exposure rates.
  spad_european_periods.csv  Non-Romanian 2015-2019 and 2020-2023 SPAD context.
  annual_count_concentration.csv
                             Largest annual share for each positive series;
                             sensitivity and diagnostic discussion.
  table_S7_accident_lags.csv Supplementary Table S7: primary-case rate ratios
                             after shifting both comparison periods 0-2 years.
  table_S8_arithmetic.csv    Supplementary Table S8: arithmetic check totals.
  table_S9_discrepancies.csv Supplementary Table S9: individual discrepancies.
  table_S11_final_probabilities.csv
                             Supplementary Table S11: four selected series at
                             all five durations, including adjusted values.
  figure_3_data.csv          Annual counts used to draw Figure 3.
  figures/figure_1.png       Figure 1: zero frequency and conservative screen.
  figures/figure_2.png       Figure 2: primary and exploratory duration profile.
  figures/figure_3.png       Figure 3: six annual precursor trajectories.
  figures/figure_1.pdf       Vector PDF counterpart of Figure 1.
  figures/figure_2.pdf       Vector PDF counterpart of Figure 2.
  figures/figure_3.pdf       Vector PDF counterpart of Figure 3.

Table S10 summarizes legal definitions rather than a numerical computation.
Table S12 combines the source and event evidence files. Their source documents
are identified by URL and page/cell references in the included catalog.

Integrity

From this directory, the following command verifies the supplied file hashes
on systems providing sha256sum:

    sha256sum -c checksums.sha256

Running the analysis into reproduced_results/ preserves the supplied results/
files. The hash list describes the supplied files, not newly created outputs.


Additional model sensitivities for the CSI zero-window audit

Use the same Python environment and source data as the main replication
package. The main command includes these analyses. To reproduce them separately, run:

  python dispersion_sensitivity.py --data data --output reproduced_sensitivities
  python serial_stress.py --data data --output reproduced_sensitivities --workers 6

The numerical configuration is recorded in analysis_config.json. These
modules supplement the five-year working-model audit. They do not replace its
primary decision rule or provide new claims of reporting completeness.

Dispersion likelihood and case parameter sensitivities

The primary fit estimates each country-indicator mean rate from all valid
years and maximizes the indicator dispersion likelihood with those rates
fixed. dispersion_likelihood_intervals.csv records that fixed-rate likelihood
and a genuine profile likelihood. In the latter, every positive-mean country's
rate is reoptimized at every alpha. The rate score is

  sum_t (Y_t - rate*E_t) / (1 + alpha*rate*E_t) = 0.

The two-sided 95% interval uses the chi-square(1) likelihood-ratio cutoff
3.841458820694124. Its upper endpoint is an asymptotic, model-based endpoint;
the six intervals are not simultaneous. It is conditional on the pooled,
independent NB2 model. The profiled estimates differ slightly from the
primary fixed-rate estimates and are identified separately in the output.

For the upper-alpha stress, the primary all-year mean rates remain fixed and
the indicator alpha is replaced by its profile upper endpoint. Only the
Poisson-surviving series at each specified duration are simulated; uncomputed
NB2 probabilities remain one, and Holm adjustment retains all 168 series.
The same full-window statistic and plus-one Monte Carlo probability are used.
This is a parameter stress analysis, not a p-value integrating over alpha
uncertainty.

The two five-year upper-alpha checks use 2,000,000 simulations each. Other
parameter sensitivity checks use 200,000 simulations each. Two further
sensitivities keep the primary dispersion and replace the generating mean
rate with the selected baseline-only rate or the rate excluding the selected
candidate zero window. These are selected-case diagnostics. Selecting the
rate-estimation interval from the observed scan does not define a newly
calibrated testing procedure.

case_parameter_sensitivities.csv records each Poisson candidate at each tested
duration, together with the rate, alpha, simulation count, exceedances,
plus-one probability, Holm-adjusted value, and decision. The nb_tail_mc_ci95
fields are pointwise Clopper-Pearson intervals for the underlying simulation
exceedance probability, before the plus-one adjustment. They describe Monte Carlo error, not parameter
uncertainty. Seeds are SeedSequence lists
[20261021, specification_index, 5, duration, series_index], with specification
indices 0 for upper alpha, 1 for baseline-only means, and 2 for candidate-
excluded means. Series indices are zero-based and indicator-major.

Dispersion heterogeneity

dispersion_by_series.csv contains a separate fixed-rate dispersion estimate
for every country-indicator series. Each mean rate uses all valid years.
All-zero and wholly missing series have no informative dispersion estimate;
their alpha is blank. Poisson boundaries are identified. The file records
the number of valid years and total events. dispersion_heterogeneity_summary.csv
reports within-indicator ranges, quartiles, and boundary counts.

Each series has at most 15 annual observations. This descriptive spread
combines estimation noise, changes in mean rates or reporting, and possible
dispersion heterogeneity. It is not a formal test proving different underlying
country dispersions. The all-year residual lag-one correlations are also
descriptive and can reflect trends or breaks. They are not estimates of the
latent Gaussian dependence parameters used below.

Baseline trend diagnostics

baseline_trend_diagnostics.csv fits an exposure-offset log-linear NB2 mean
to the five baseline years of the four selected cases, holding the primary
indicator alpha fixed. Slope likelihood intervals reoptimize the intercept.
The output includes the annual rate ratio, pointwise likelihood interval,
descriptive likelihood-ratio statistic, and extrapolated candidate mean.
The conditional all-zero probability uses the fitted extrapolated annual
means and assumes independent NB2 years.

The fits omit the selected zero window but have only five observations each.
Their probabilities do not adjust for case or window selection and do not
integrate slope or dispersion uncertainty. Strong extrapolation from a single
large baseline year can produce an implausibly large forecast. These values
describe the estimates and extrapolations of the baseline-only trend model;
they are not alternative full-scan inferential results.

Serial-dependence stress calibration

For each series, a stationary latent Gaussian process satisfies

  Z_1 ~ Normal(0,1),
  Z_t = rho*Z_(t-1) + sqrt(1-rho^2)*epsilon_t,
  epsilon_t independently ~ Normal(0,1).

Applying the standard normal cumulative distribution function makes every
annual marginal uniform. Applying the inverse of the fitted annual NB2 CDF
therefore preserves exactly that annual NB2 marginal distribution. Rho is
the latent Gaussian AR(1) coefficient; it is not the count autocorrelation.
The values 0, 0.3, and 0.6 are specified stresses, not estimated correlations.
Country-indicator series are mutually independent in the generator. Latent
states advance across every calendar year, including masked missing years.

The generator creates 2,000 panels at each rho. Every generated panel retains
the observed exposure and missingness pattern. The analysis then refits all
country rates and indicator dispersions, scans complete five-year baselines
and five-year candidate windows, applies the Poisson screen, runs 200,000
independent-model NB2 inner simulations for each surviving series, and applies
the full Holm168 intersection. Thus the stress asks how the independent-model
procedure behaves when marginal means and variances remain fixed but annual
independence fails. It does not recalibrate the inner procedure to a fitted
serial model or claim universal error control.

The simple comparison rule marks any series containing a complete 5+5-year
position with baseline sum at least 15 and five candidate zeros. It is a
fixed-count rule, distinct from the exposure-specific conservative screen.

serial_stress_summary.csv gives the simple-rule, Poisson-prefilter, and final
panel flag rates and exact 95% binomial intervals. serial_stress_panels.csv
contains 6,000 generated-panel decisions and refitted dispersions.
serial_stress_inner_checks.csv contains all individual independent-model
NB2 checks applied within the stress panels.

Outer seeds are [20261022, rho_code, panel_index, 0]; inner seeds are
[20261022, rho_code, panel_index, 1, series_index]. Rho codes are 0, 300, and
600; panel_index runs from 0 to 1999 within each setting. The independent
rho=0 comparator uses this inverse-CDF generator and seed, which differ from
the direct NB2 generator and seed of the main independent calibration.

Observed-case serial sensitivity

observed_serial_sensitivity.csv reports full-scan Monte Carlo probabilities
for the two observed five-year Poisson candidates under the same copula NB2
model at rho=0.3 and rho=0.6. All 200,000 simulations enter each denominator.
Holm adjustment covers 168 series, with noncandidates set to one. These
selected-case model stresses use primary fitted means and dispersions and
do not replace the primary method. The seeds are [20261023, rho_code,
series_index]. The pointwise Monte Carlo intervals are defined as above.

Simulation batches contain 20,000 rows. Worker count does not change the
streams. The inverse-CDF implementation covers the largest generated uniform
value in each batch and applies no tail clipping.


Calendar sensitivity and simple-rule comparison

calendar_diagnostics.py reports complete zero-window positions, the timing of
selected windows, and zero runs that begin in 2020 after a positive 2019 count.
For the calendar sensitivity, the 2020 and 2021 count cells become missing and
ineligible. The annual calendar remains unchanged. Every comparison spanning
either year becomes ineligible. The five-year procedure is then refitted and
repeated with seed 20271019 and 200,000 inner draws for each Poisson survivor.
The exclusion leaves 156 series with complete comparisons and 17 with a
qualifying zero window; both model stages produce zero flags. The two selected
primary windows are ineligible under this exclusion.

simple_rule_comparison.csv compares the actual audit with a fixed-count rule
using at least 22, 18, 15, 13, or 11 baseline events for zero-window durations
3, 4, 5, 6, or 7. Every comparison has a complete five-year baseline. The rule
flags a series if any complete position qualifies. These floors describe the
equal-annual-exposure reference and are distinct from the exposure-specific
conservative screen. At five years, the observed rule and model decisions
agree; they differ at three and four years. Simulated error-rate comparisons
for the five-year rule are in serial_stress_summary.csv.

Additional file relationships

  dispersion_sensitivity.py            Supplementary Section S13.
  serial_stress.py                     Supplementary Section S14.
  calendar_diagnostics.py              Supplementary Section S15.
  results/dispersion_likelihood_intervals.csv
                                      Table S13 pooled likelihood intervals.
  results/dispersion_by_series.csv     Country-level dispersion estimates.
  results/dispersion_heterogeneity_summary.csv
                                      Table S13 within-indicator ranges.
  results/case_parameter_sensitivities.csv
                                      Table S13a and main sensitivity text.
  results/baseline_trend_diagnostics.csv
                                      Table S13b selected baseline trends.
  results/serial_stress_summary.csv    Table S14 full-procedure flag rates.
  results/serial_stress_panels.csv      Decisions for all 6,000 stress panels.
  results/serial_stress_inner_checks.csv
                                      All 1,810 inner checks in those panels.
  results/observed_serial_sensitivity.csv
                                      Table S14a observed-case sensitivities.
  results/simple_rule_summary.csv      Table S15 duration-specific decisions.
  results/simple_rule_comparison.csv   All 168 series at each duration.
  results/zero_window_timing.csv       Table S15a timing summaries.
  results/complete_zero_windows.csv    All qualifying calendar positions.
  results/pandemic_exclusion_scan.csv  All 168 five-year exclusion results.
  results/pandemic_exclusion_summary.csv
                                      Eligibility and decisions after exclusion.
  results/romania_annual_context.csv   Reported Romanian counts and exposure.
  results/romania_period_context.csv   Period totals and annual mean exposure.

The full run includes 10,000 outer panels and the specified inner simulations.
Its computing time depends on hardware and the number of Poisson candidates.
The supplied result files allow review of every reported number before rerun.


Event-source scope

Table S12 reviews nine selected Romanian reports for events during 2020-2023.
Seven documented movements meet the aggregate SPAD definition: one in 2021,
one in 2022, and five in 2023. The CSI total and both subtypes are zero in each
of those years. The evidence catalogue records each event's date, report date,
facts, page references, inclusion criterion, and classification. Galați and
Valea Seacă remain outside the confirmed minimum for the reasons in that file.
The minimum describes the selected public reports; it is not a national event
inventory. The Valea Seacă source is a PDF member of the official 2020 ZIP
archive. source_catalog.csv gives the exact member name and extracted PDF hash.

Observed dependence and aggregate comparisons

The descriptive dependence analysis uses 2,130 complete adjacent-year pairs
from 156 positive-total series. Twelve all-zero series have degenerate fitted
means and contribute no dependence information. Marginal randomized-quantile
correlations average sufficient statistics over 512 independent randomisations.
The latent Gaussian correlation is estimated separately by integrating the
adjacent-pair probability rectangles defined by the discrete NB2 marginals.
The integration uses 96 Gauss-Legendre nodes. A 0.005 correlation grid from
-0.60 to 0.95 is refined locally by a parabola.

Both constant-rate and log-linear mean specifications retain the primary
indicator dispersions. Log-linear means use all valid observed years; three
boundary trend fits retain their constant-rate means. Country-block bootstrap
intervals use 2,000 resamples of the 28 countries and hold fitted margins fixed.
The diagnostic therefore describes dependence conditional on the chosen mean
and dispersion model. It does not turn the specified stress calibration into
an error guarantee for an adaptively estimated dependence model.

The pooled marginal-residual correlations are 0.311762 and 0.110450 under
constant-rate and log-linear means. Corresponding conditional latent estimates
are 0.434076 and 0.268384. Seeds and repetition counts appear in
analysis_config.json. Table S16 reports all six indicators and the pooled fit.

Romania's recorded baseline rate is 1777 / 423.1 = 4.199953 events per million
train-kilometres. Under an unchanged-rate assumption, 313.6 million train-
kilometres imply 1317.105176 events during 2020-2023. That scenario quantity is
separate from the seven qualifying events in the supplied event catalogue.
The reported pooled study rate rises 1.208899% with Romania included and
16.503863% with Romania excluded. Adding only the documented minimum produces
a 1.280145% increase; adding the unchanged-rate scenario quantity produces a
14.614246% increase. The source register is left unchanged.

Additional reproducible outputs

  dependence_diagnostics.py     Observed residual and pairwise latent fits.
  evidence_summaries.py         Coverage, annual trend predictions, scenarios.
  results/dependence_diagnostics.csv
                               Main Section 5.4 and supplementary Table S16.
  results/dependence_fitted_margins.csv
                               Fitted marginal means and boundary-fallback flags.
  results/dependence_bootstrap.csv
                               Country-block estimates for Table S16 intervals.
  results/comparison_coverage.csv
                               Main Table 1 totals and Section 5.1 progression.
  results/baseline_trend_predictions.csv
                               Annual means/probabilities behind main Table 4
                               and supplementary Table S13b.
  results/aggregate_country_periods.csv
                               Country inputs for main Section 5.2 and Table S17.
  results/romania_rate_scenario.csv
                               Observed baseline, event minimum and rate scenario.
  results/aggregate_rate_scenarios.csv
                               Study aggregate comparisons in Table S17.

To reproduce only these diagnostics and summary calculations, run:

    python dependence_diagnostics.py --data data --output diagnostic_results
    python evidence_summaries.py --data data --output diagnostic_results

The complete command at the beginning also executes both modules. It reruns
all nested simulations and can require substantial computation time. Scientific Monte Carlo and bootstrap outputs are included in results/.
