"""End-to-end calibration of the five-year Poisson/NB2 audit.

Each generated panel is refitted before the complete two-stage decision rule is
applied. Independent panel/series seed streams give the same results for any
worker count. Reported intervals are two-sided Clopper-Pearson intervals.
"""
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import numpy as np
import pandas as pd
from audit_engine import (fit_nb2, make_geometry, scan_arrays,
                          mc_scan_probability, holm_log, binomial_interval)

_PANEL = _TRUTH = _GEOMETRY = _CONFIG = None


def initialize_worker(panel, truth, config):
    global _PANEL, _TRUTH, _GEOMETRY, _CONFIG
    _PANEL, _TRUTH, _CONFIG = panel, truth, config
    _GEOMETRY = make_geometry(panel, config["baseline_years"], config["window_years"])


def calibrate_one(job):
    model, index = job
    words = [_CONFIG["seed"], 100 if model == "poisson" else 200, index]
    rng = np.random.default_rng(np.random.SeedSequence(words + [0]))
    mu = _TRUTH["means"]
    if model == "poisson":
        y = rng.poisson(mu)
    else:
        y = np.zeros(mu.shape, dtype=np.int64)
        for ii, alpha in enumerate(_TRUTH["alpha"]):
            if alpha == 0:
                y[ii] = rng.poisson(mu[ii])
            else:
                size = 1.0 / alpha
                y[ii] = rng.negative_binomial(size, size / (size + mu[ii]))
    fitted = fit_nb2(_PANEL, y)
    if not np.all(fitted["converged"]):
        raise RuntimeError(f"NB2 dispersion optimization did not converge: {job}")
    scan = scan_arrays(y, _GEOMETRY)
    candidates = np.flatnonzero(scan["poisson_flag"])
    n, t = _GEOMETRY["valid"].shape
    means = fitted["means"].reshape(n, t)
    nc = len(_PANEL["countries"])
    pnb = np.ones(n)
    mc_details = []
    for j in candidates:
        pnb[j], hits = mc_scan_probability(
            means[j], fitted["alpha"][j // nc], _GEOMETRY, j,
            scan["log_raw_p"][j], draws=_CONFIG["inner_draws"],
            seed=words + [1, int(j)], chunk_size=_CONFIG["chunk_size"])
        mc_details.append(dict(country=_PANEL["countries"][j % nc],
                               indicator=_PANEL["indicators"][j // nc],
                               exceedances=hits, nb_raw_p=pnb[j],
                               observed_log_t=float(scan["log_raw_p"][j])))
    nb_holm = np.exp(holm_log(np.log(pnb)))
    final = scan["poisson_flag"] & (nb_holm <= 0.05)
    final_ids = [f"{_PANEL['countries'][j % nc]}-{_PANEL['indicators'][j // nc]}"
                 for j in np.flatnonzero(final)]
    for detail, j in zip(mc_details, candidates):
        detail["nb_holm_p"] = nb_holm[j]
        detail["final_flag"] = bool(final[j])
    result = dict(null_model=model, panel_index=index,
                  poisson_flags=int(np.sum(scan["poisson_flag"])),
                  inner_series_tested=len(candidates), final_flags=int(final.sum()),
                  final_flag_ids=";".join(final_ids),
                  refitted_nb2_poisson_boundaries=int(fitted["poisson_boundary"].sum()),
                  mc_details=mc_details)
    for ii, code in enumerate(_PANEL["indicators"]):
        result[f"refitted_alpha_{code}"] = float(fitted["alpha"][ii])
        result[f"refitted_n_{code}"] = int(fitted["nobs"][ii])
    return result


def summarize(rows):
    output = []
    for model in ["poisson", "nb2"]:
        selected = [r for r in rows if r["null_model"] == model]
        if not selected:
            continue
        n = len(selected)
        for stage, key in [("poisson_prefilter", "poisson_flags"), ("final_intersection", "final_flags")]:
            counts = [r[key] for r in selected]
            successes = sum(k > 0 for k in counts)
            low, high = binomial_interval(successes, n)
            output.append(dict(null_model=model, procedure=stage, panels=n,
                               panels_with_flag=successes, familywise_flag_rate=successes / n,
                               ci95_low=low, ci95_high=high, ci_method="Clopper-Pearson",
                               mean_flags=float(np.mean(counts)), max_flags=max(counts),
                               total_inner_series=sum(r["inner_series_tested"] for r in selected)))
    return pd.DataFrame(output)



def calibrate(panel, output, panels=2000, draws=200000, workers=6,
              seed=20261010, chunk_size=20000):
    """Write panel, inner-check, and summary CSVs; return the summary DataFrame.

    Parameters
    ----------
    panel : dict
        Array panel returned by audit_engine.load_panel.
    output : path-like
        Destination directory for the three scientific result tables.
    panels : int
        Number of independent outer panels per null model.
    draws : int
        Full-scan Monte Carlo draws per Poisson-surviving series.
    workers : int
        Parallel worker processes. This does not alter random streams.
    seed : int
        Root seed; default 20261010.
    chunk_size : int
        Maximum inner simulation rows generated together.

    The observed fitted rates and dispersions define the generating nulls.
    Each outer panel then receives new rate and dispersion estimates. The
    Poisson and NB2 stages both retain the complete country-indicator family.
    """
    if min(panels, draws, workers, chunk_size) < 1:
        raise ValueError("Panel, draw, worker and chunk counts must be positive")
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    truth = fit_nb2(panel)
    config = dict(seed=int(seed), baseline_years=5, window_years=5,
                  inner_draws=int(draws), chunk_size=int(chunk_size))
    jobs = [(model, i) for i in range(panels) for model in ["poisson", "nb2"]]
    with ProcessPoolExecutor(max_workers=workers, initializer=initialize_worker,
                             initargs=(panel, truth, config)) as pool:
        rows = list(pool.map(calibrate_one, jobs, chunksize=1))
    public_rows = [{key: value for key, value in row.items() if key != "mc_details"}
                   for row in rows]
    pd.DataFrame(public_rows).to_csv(output / "calibration_panels.csv", index=False)
    details = []
    for row in rows:
        details.extend([dict(null_model=row["null_model"], panel_index=row["panel_index"], **detail)
                        for detail in row["mc_details"]])
    columns = ["null_model", "panel_index", "country", "indicator", "exceedances",
               "nb_raw_p", "observed_log_t", "nb_holm_p", "final_flag"]
    pd.DataFrame(details, columns=columns).to_csv(output / "calibration_inner_checks.csv", index=False)
    summary = summarize(rows)
    summary.to_csv(output / "calibration_summary.csv", index=False)
    return summary
