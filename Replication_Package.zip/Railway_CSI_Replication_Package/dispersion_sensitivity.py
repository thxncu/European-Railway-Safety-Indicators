"""Dispersion, fitted-mean, and descriptive baseline-trend sensitivities."""
from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar, brentq
from scipy.special import gammaln, xlogy
from scipy.stats import chi2

from audit_engine import (load_panel, fit_nb2, run_audit, scan_panel,
                          make_geometry, mc_scan_probability, holm_log, binomial_interval)
from report_outputs import read_source


def nb_loglik(y, mu, alpha):
    """Elementwise NB2 likelihood, including its Poisson boundary."""
    if alpha == 0:
        return xlogy(y, mu) - mu - gammaln(y + 1)
    size = 1 / alpha
    return (gammaln(y + size) - gammaln(size) - gammaln(y + 1)
            + xlogy(y, alpha * mu) - (y + size) * np.log1p(alpha * mu))


def profiled_rates(y, exposure, alpha):
    """Maximize each NB2 exposure-offset intercept at fixed alpha.

    The score in log(rate) is sum((y-mu)/(1+alpha*mu)); it is strictly
    decreasing for a positive-total series. Bisection brackets that score.
    Missing cells must already have count=exposure=0.
    """
    total_y, total_e = y.sum(axis=1), exposure.sum(axis=1)
    rate = np.divide(total_y, total_e, out=np.zeros_like(total_e), where=total_e>0)
    active = total_y > 0
    if alpha == 0 or not np.any(active):
        return rate
    center = np.log(rate[active])
    lower, upper = center - 30, center + 30
    yy, ee = y[active], exposure[active]
    for _ in range(70):
        middle = (lower + upper) / 2
        mu = np.exp(middle[:, None]) * ee
        score = np.sum((yy - mu) / (1 + alpha * mu), axis=1)
        lower = np.where(score > 0, middle, lower)
        upper = np.where(score > 0, upper, middle)
    rate[active] = np.exp((lower + upper) / 2)
    return rate


def profile_interval(y, exposure, profile_rates=True):
    """Likelihood-ratio 95% interval, with chi-square(1) reference cutoff.

    With profile_rates=False this is a fixed-rate likelihood-support
    interval. With True, all positive-mean country rates are nuisance
    parameters profiled at every alpha. The intervals are model-based,
    asymptotic, indicator-specific, and not simultaneous across indicators.
    """
    fixed = profiled_rates(y, exposure, 0)
    def ll(alpha):
        rates = profiled_rates(y, exposure, alpha) if profile_rates else fixed
        return float(nb_loglik(y, rates[:, None] * exposure, alpha).sum())
    optimum = minimize_scalar(lambda a:-ll(np.exp(a)), bounds=(-12, 8),
                              method='bounded', options={'xatol':1e-9})
    alpha = float(np.exp(optimum.x))
    best = ll(alpha)
    if ll(0) >= best:
        alpha, best = 0., ll(0)
    cutoff = float(chi2.ppf(.95, 1))
    target = best - cutoff / 2
    lower = 0.
    if alpha > 0 and ll(0) < target:
        lower = float(np.exp(brentq(lambda x:ll(np.exp(x))-target,
                                    -20, np.log(alpha), xtol=1e-10)))
    hi = max(1., alpha * 2)
    while ll(hi) > target and hi < 1e8:
        hi *= 2
    if ll(hi) > target:
        raise RuntimeError('Profile likelihood upper endpoint was not bracketed')
    upper = float(np.exp(brentq(lambda x:ll(np.exp(x))-target,
                                np.log(max(alpha, 1e-12)), np.log(hi), xtol=1e-10)))
    return dict(alpha_mle=alpha, ci95_lower=lower, ci95_upper=upper,
                log_likelihood=best, likelihood_ratio_cutoff=cutoff,
                upper_likelihood_ratio=2*(best-ll(upper)),
                converged=bool(optimum.success))


def dispersion_outputs(panel, output):
    output = Path(output)
    fit = fit_nb2(panel)
    rows, series = [], []
    for ii, indicator in enumerate(panel['indicators']):
        valid = panel['valid'][ii]
        y = np.where(valid, panel['counts'][ii], 0.)
        e = np.where(valid, panel['exposure'][ii], 0.)
        for profile in [False, True]:
            interval = profile_interval(y, e, profile)
            rows.append(dict(indicator=indicator,
                             likelihood='profiled_country_rates' if profile else 'fixed_country_rates',
                             original_alpha=fit['alpha'][ii],
                             observations=int(fit['nobs'][ii]), **interval))
        for cc, country in enumerate(panel['countries']):
            observed = valid[cc]
            yc, ec = y[cc, observed], e[cc, observed]
            positive = len(yc)>0 and yc.sum()>0
            alpha, ll, boundary, correlation = np.nan, np.nan, False, np.nan
            if positive:
                mu = yc.sum()/ec.sum()*ec
                result = minimize_scalar(lambda a:-float(nb_loglik(yc,mu,np.exp(a)).sum()),
                                         bounds=(-12,8),method='bounded',options={'xatol':1e-8})
                ll_p = float(nb_loglik(yc,mu,0).sum())
                boundary = result.x <= -11.99 or -result.fun <= ll_p
                alpha = 0. if boundary else float(np.exp(result.x))
                ll = ll_p if boundary else float(-result.fun)
                residual = np.full(len(observed),np.nan)
                residual[observed] = (yc-mu)/np.sqrt(mu+fit['alpha'][ii]*mu**2)
                pairs = np.isfinite(residual[:-1]) & np.isfinite(residual[1:])
                if pairs.sum()>2:
                    x,z=residual[:-1][pairs],residual[1:][pairs]
                    if np.std(x)>0 and np.std(z)>0:
                        correlation = float(np.corrcoef(x,z)[0,1])
            series.append(dict(country=country,indicator=indicator,
                               valid_years=int(observed.sum()),total_events=float(yc.sum()),
                               alpha_fixed_rate=alpha, pooled_alpha=fit['alpha'][ii],
                               poisson_boundary=boundary, informative=bool(positive),
                               log_likelihood=ll, residual_lag1_correlation=correlation))
    intervals=pd.DataFrame(rows)
    detail=pd.DataFrame(series)
    summary=[]
    for indicator,g in detail.groupby('indicator',sort=False):
        good=g[g.informative]
        a=good.alpha_fixed_rate
        summary.append(dict(indicator=indicator,positive_series=len(good),
                            all_zero_or_missing_series=int((~g.informative).sum()),
                            poisson_boundary_series=int(good.poisson_boundary.sum()),
                            alpha_min=a.min(),alpha_q25=a.quantile(.25),alpha_median=a.median(),
                            alpha_q75=a.quantile(.75),alpha_max=a.max(),
                            alpha_above_pooled=int((a>good.pooled_alpha).sum()),
                            median_valid_years=good.valid_years.median(),
                            median_residual_lag1=good.residual_lag1_correlation.median()))
    intervals.to_csv(output/'dispersion_likelihood_intervals.csv',index=False)
    detail.to_csv(output/'dispersion_by_series.csv',index=False)
    pd.DataFrame(summary).to_csv(output/'dispersion_heterogeneity_summary.csv',index=False)
    return fit,intervals,detail


def case_sensitivities(panel, fit, intervals, output, draws=200000, seed=20261021,
                       primary_upper_draws=2000000):
    """Retest existing Poisson candidates, retaining Holm168 at each duration."""
    output=Path(output)
    upper=intervals[intervals.likelihood=='profiled_country_rates'].set_index('indicator').ci95_upper
    rows=[]
    nc=len(panel['countries'])
    for duration in [3,4,5,6,7]:
        scan=scan_panel(panel,baseline_years=5,window_years=duration)
        geometry=make_geometry(panel,5,duration)
        means=fit['means'].reshape(168,-1)
        for spec_index,spec in enumerate(['profile_alpha_upper','baseline_only_mean','candidate_excluded_mean']):
            probabilities=np.ones(168)
            details=[]
            for j in np.flatnonzero(scan.poisson_flag):
                row=scan.loc[j]
                ii,cc=divmod(int(j),nc)
                mu=means[j].copy()
                alpha=fit['alpha'][ii]
                selected_rate=float(fit['rates'][ii,cc])
                if spec=='profile_alpha_upper':
                    alpha=float(upper[panel['indicators'][ii]])
                else:
                    years=panel['years']
                    keep=panel['valid'][ii,cc].copy()
                    if spec=='baseline_only_mean':
                        keep &= (years>=row.baseline_start)&(years<=row.baseline_end)
                    else:
                        keep &= ~((years>=row.window_start)&(years<=row.window_end))
                    selected_rate=float(panel['counts'][ii,cc,keep].sum()/panel['exposure'][ii,cc,keep].sum())
                    mu=selected_rate*np.where(panel['valid'][ii,cc],panel['exposure'][ii,cc],0.)
                number=primary_upper_draws if spec=='profile_alpha_upper' and duration==5 else draws
                probabilities[j],hits=mc_scan_probability(mu,alpha,geometry,int(j),row.log_raw_p,
                    draws=number,seed=[seed,spec_index,5,duration,int(j)],chunk_size=20000)
                mc_low,mc_high=binomial_interval(hits,number)
                details.append(dict(specification=spec,window_years=duration,country=row.country,
                    indicator=row.indicator,series_index=int(j),alpha=alpha,fitted_rate=selected_rate,
                    baseline_start=row.baseline_start,window_start=row.window_start,window_end=row.window_end,
                    poisson_holm_p=row.poisson_holm_p,nb_exceedances=hits,nb_draws=number,
                    nb_raw_p=probabilities[j],nb_tail_mc_ci95_low=mc_low,
                    nb_tail_mc_ci95_high=mc_high))
            adjusted=np.exp(holm_log(np.log(probabilities)))
            for row in details:
                row['nb_holm_p']=adjusted[row['series_index']]
                row['final_flag']=bool(row['nb_holm_p']<=.05)
                rows.append(row)
    frame=pd.DataFrame(rows)
    frame.to_csv(output/'case_parameter_sensitivities.csv',index=False)
    return frame


def baseline_trend_diagnostics(panel, fit, output):
    """Descriptive baseline-only log-linear fits with pooled alpha fixed.

    Fits assess whether five baseline years support a trend and display its
    extrapolation. They are not selection-adjusted full-scan p-values.
    """
    rows=[]
    cases=[('BG','I02',5),('PL','I03',5),('RO','I04',3),('BG','I06',3)]
    for country,indicator,duration in cases:
        ii=panel['indicators'].index(indicator);cc=panel['countries'].index(country)
        selected=scan_panel(panel,window_years=duration).query('country==@country and indicator==@indicator').iloc[0]
        years=panel['years'];keep=(years>=selected.baseline_start)&(years<=selected.baseline_end)
        t=years[keep]-years[keep].mean();y=panel['counts'][ii,cc,keep];e=panel['exposure'][ii,cc,keep]
        alpha=float(fit['alpha'][ii])
        # A scalar conditional intercept maximum supports slope profile limits.
        def slope_ll(slope):
            tilted=e*np.exp(slope*t)
            rate=profiled_rates(y[None,:],tilted[None,:],alpha)[0]
            return float(nb_loglik(y,rate*tilted,alpha).sum())
        slope_fit=minimize_scalar(lambda s:-slope_ll(s),bounds=(-5,5),method='bounded',options={'xatol':1e-9})
        slope=float(slope_fit.x);best=-slope_fit.fun
        target=best-chi2.ppf(.95,1)/2
        lower=brentq(lambda s:slope_ll(s)-target,-10,slope) if slope_ll(-10)<target else -np.inf
        upper=brentq(lambda s:slope_ll(s)-target,slope,10) if slope_ll(10)<target else np.inf
        rate=profiled_rates(y[None,:],(e*np.exp(slope*t))[None,:],alpha)[0]
        win=(years>=selected.window_start)&(years<=selected.window_end)
        pred=rate*panel['exposure'][ii,cc,win]*np.exp(slope*(years[win]-years[keep].mean()))
        pzero=float(np.exp(np.sum(-np.log1p(alpha*pred)/alpha)))
        rows.append(dict(country=country,indicator=indicator,window_years=duration,
            baseline_start=int(selected.baseline_start),baseline_end=int(selected.baseline_end),
            baseline_years=len(y),baseline_events=float(y.sum()),fixed_pooled_alpha=alpha,
            slope_per_year=slope,annual_rate_ratio=float(np.exp(slope)),
            slope_ci95_lower=lower,slope_ci95_upper=upper,
            annual_rate_ratio_ci95_lower=float(np.exp(lower)),annual_rate_ratio_ci95_upper=float(np.exp(upper)),
            trend_likelihood_ratio=2*(best-slope_ll(0)),
            trend_descriptive_p=float(chi2.sf(2*(best-slope_ll(0)),1)),
            extrapolated_window_mean=float(pred.sum()),
            conditional_window_zero_probability=pzero,
            profile_converged=bool(slope_fit.success),
            slope_at_search_boundary=bool(abs(slope)>4.99)))
    frame=pd.DataFrame(rows)
    frame.to_csv(Path(output)/'baseline_trend_diagnostics.csv',index=False)
    return frame


def run(data,output,draws=200000):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    panel=load_panel(read_source(data))
    fit,intervals,detail=dispersion_outputs(panel,output)
    sensitivity=case_sensitivities(panel,fit,intervals,output,draws=draws)
    trends=baseline_trend_diagnostics(panel,fit,output)
    print(intervals[intervals.likelihood=='profiled_country_rates'].to_string(index=False),flush=True)
    print(sensitivity[sensitivity.window_years==5].to_string(index=False),flush=True)
    print(trends.to_string(index=False),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--draws',type=int,default=200000)
    args=parser.parse_args()
    run(args.data,args.output,args.draws)
